﻿[
  {
    "__metadata": {
      "id": "Web/Lists(guid'01a935ee-3173-4fba-91c2-78a924bebb06')/Items(6)",
      "uri": "https://navsea.navy.deps.mil/wc/surinhd/e/private/vmr/_api/Web/Lists(guid'01a935ee-3173-4fba-91c2-78a924bebb06')/Items(6)",
      "etag": "\"23\"",
      "type": "SP.Data.ValueManagementMainListItem"
    },
    "FirstUniqueAncestorSecurableObject": {
      "__deferred": {
        "uri": "https://navsea.navy.deps.mil/wc/surinhd/e/private/vmr/_api/Web/Lists(guid'01a935ee-3173-4fba-91c2-78a924bebb06')/Items(6)/FirstUniqueAncestorSecurableObject"
      }
    },
    "RoleAssignments": {
      "__deferred": {
        "uri": "https://navsea.navy.deps.mil/wc/surinhd/e/private/vmr/_api/Web/Lists(guid'01a935ee-3173-4fba-91c2-78a924bebb06')/Items(6)/RoleAssignments"
      }
    },
    "AttachmentFiles": {
      "__deferred": {
        "uri": "https://navsea.navy.deps.mil/wc/surinhd/e/private/vmr/_api/Web/Lists(guid'01a935ee-3173-4fba-91c2-78a924bebb06')/Items(6)/AttachmentFiles"
      }
    },
    "ContentType": {
      "__deferred": {
        "uri": "https://navsea.navy.deps.mil/wc/surinhd/e/private/vmr/_api/Web/Lists(guid'01a935ee-3173-4fba-91c2-78a924bebb06')/Items(6)/ContentType"
      }
    },
    "FieldValuesAsHtml": {
      "__deferred": {
        "uri": "https://navsea.navy.deps.mil/wc/surinhd/e/private/vmr/_api/Web/Lists(guid'01a935ee-3173-4fba-91c2-78a924bebb06')/Items(6)/FieldValuesAsHtml"
      }
    },
    "FieldValuesAsText": {
      "__deferred": {
        "uri": "https://navsea.navy.deps.mil/wc/surinhd/e/private/vmr/_api/Web/Lists(guid'01a935ee-3173-4fba-91c2-78a924bebb06')/Items(6)/FieldValuesAsText"
      }
    },
    "FieldValuesForEdit": {
      "__deferred": {
        "uri": "https://navsea.navy.deps.mil/wc/surinhd/e/private/vmr/_api/Web/Lists(guid'01a935ee-3173-4fba-91c2-78a924bebb06')/Items(6)/FieldValuesForEdit"
      }
    },
    "File": {
      "__deferred": {
        "uri": "https://navsea.navy.deps.mil/wc/surinhd/e/private/vmr/_api/Web/Lists(guid'01a935ee-3173-4fba-91c2-78a924bebb06')/Items(6)/File"
      }
    },
    "Folder": {
      "__deferred": {
        "uri": "https://navsea.navy.deps.mil/wc/surinhd/e/private/vmr/_api/Web/Lists(guid'01a935ee-3173-4fba-91c2-78a924bebb06')/Items(6)/Folder"
      }
    },
    "ParentList": {
      "__deferred": {
        "uri": "https://navsea.navy.deps.mil/wc/surinhd/e/private/vmr/_api/Web/Lists(guid'01a935ee-3173-4fba-91c2-78a924bebb06')/Items(6)/ParentList"
      }
    },
    "PPID": {
      "__metadata": {
        "id": "43d948b5-2073-4e3f-83c3-31c71614fddb",
        "type": "SP.Data.PPIDBookListItem"
      },
      "Title": "AD94"
    },
    "PM": {
      "__metadata": {
        "id": "d0907584-3634-4e15-9b01-c2984d7ddbbf",
        "type": "SP.Data.ProjectManagersListItem"
      },
      "Title": "Didion, Amy J. CIV NSWC IHEODTD"
    },
    "PjMCode": {
      "__metadata": {
        "id": "b0e62b11-e611-4a12-8249-7ce8e5621022",
        "type": "SP.Data.Org_x0020_TableListItem"
      },
      "Title": "M",
      "Branch": "MP",
      "Div": "MP"
    },
    "CA": {
      "__metadata": {
        "id": "7984287c-75d7-4862-b6ab-54d2bfae5b49",
        "type": "SP.Data.CAsListItem"
      },
      "Title": "THRIFT MICHAEL"
    },
    "ERPResourceSponsor": {
      "__metadata": {
        "id": "ed52f59b-4aed-4987-ab5a-93a107cf9f43",
        "type": "SP.Data.ERPResourceSponsorListItem"
      },
      "Title": "PRIVATE PARTY"
    },
    "FileSystemObjectType": 0,
    "Id": 6,
    "ContentTypeId": "0x0100DB9B5F07A13E82418DDBC051B949FE86",
    "Title": "DR-027252",
    "PPIDId": 4178,
    "AuthorId": 1456,
    "EditorId": 1378,
    "Modified": "2017-08-08T20:06:19Z",
    "Created": "2016-11-09T14:57:39Z",
    "ProjectTitle": "NAMMO TALLEY LAW M72A9",
    "ProjectDescription": "\n\nENGINEERING AND PRODUCTION OF M72A9 LAW\n\n\n\n",
    "PMId": 293,
    "PjMCodeId": 40,
    "CostHighlights": null,
    "DeliverableMilestonesEditRecordId": 10,
    "VarianceEditRecordId": 10,
    "VarianceLink": {
      "__metadata": {
        "type": "SP.FieldUrlValue"
      },
      "Description": "https://navsea.portal.navy.mil/wc/surinhd/e/private/vmr/Lists/VMVarianceEdit/Item/editifs.aspx?ID=10",
      "Url": "https://navsea.navy.deps.mil/wc/surinhd/e/private/vmr/Lists/VMVarianceEdit/Item/editifs.aspx?ID=10"
    },
    "ValueMan": null,
    "MilestonesAndDeliverablesLink": {
      "__metadata": {
        "type": "SP.FieldUrlValue"
      },
      "Description": "https://navsea.portal.navy.mil/wc/surinhd/e/private/vmr/Lists/VMDeliverableMilestonesEdit/Item/editifs.aspx?ID=10",
      "Url": "https://navsea.navy.deps.mil/wc/surinhd/e/private/vmr/Lists/VMDeliverableMilestonesEdit/Item/editifs.aspx?ID=10"
    },
    "CAId": 4,
    "CustomerSatisfied": "Yes",
    "PlannedStart": "2012-04-15T04:00:00Z",
    "ActualStart": "2012-07-14T04:00:00Z",
    "PlannedFinish": "2015-12-31T05:00:00Z",
    "ActualFinish": "2015-12-31T05:00:00Z",
    "Status": "Complete",
    "WYValueM": null,
    "WYValueR": null,
    "WYValue01": null,
    "WYValue02": null,
    "WYValue10": 0,
    "WYValueTD": null,
    "WYValueD": null,
    "WYValueE": null,
    "WYValueG": null,
    "WYValueJP": null,
    "CostEvalId": null,
    "CostTrendId": null,
    "PrevCostEvalId": null,
    "ScheduleTrendId": null,
    "ScheduleEvalId": null,
    "PrevScheduleEvalId": null,
    "ScheduleHighlights": null,
    "TechnicalTrendId": null,
    "TechnicalEvalId": null,
    "PrevTechnicalEvalId": null,
    "TechnicalHighlights": null,
    "QualityTrendId": null,
    "QualityEvalId": null,
    "PrevQualityEvalId": null,
    "QualityHighlights": null,
    "FundingTrendId": null,
    "FundingEvalId": null,
    "PrevFundingEvalId": null,
    "FundingHighlights": null,
    "PeopleTrendId": null,
    "PeopleEvalId": null,
    "PrevPeopleEvalId": null,
    "PeopleHighlights": null,
    "EquipmentTrendId": null,
    "EquipmentEvalId": null,
    "PrevEquipmentEvalId": null,
    "EquipmentHighlights": null,
    "FacilitiesTrendId": null,
    "FacilitiesEvalId": null,
    "PrevFacilitiesEvalId": null,
    "FacilitiesHighlights": null,
    "DocumentsTrendId": null,
    "DocumentsEvalId": null,
    "PrevDocumentsEvalId": null,
    "DocumentsHighlights": null,
    "HardwareTrendId": null,
    "HardwareEvalId": null,
    "PrevHardwareEvalId": null,
    "HardwareHighlights": null,
    "IngredientsTrendId": null,
    "IngredientsEvalId": null,
    "PrevIngredientsEvalId": null,
    "IngredientsHighlights": null,
    "ERPResourceSponsorId": 644,
    "OverallTrendId": null,
    "OverallEvalId": null,
    "PrevOverallEvalId": null,
    "FundingPlanned": 10668000,
    "FundingReceived": 5639818,
    "FYFundingPlanned": 0,
    "FYFundingCarryIn": 0,
    "FYFundingNew": 0,
    "FYFundingDC": 0,
    "FYFundingContingentLs": 0,
    "FYFundingAvailable": 0,
    "PPIDLink": {
      "__metadata": {
        "type": "SP.FieldUrlValue"
      },
      "Description": "https://navsea.portal.navy.mil/wc/surinhd/e/private/vmr/Lists/PPIDBook/Item/displayifs.aspx?ID=4178",
      "Url": "https://navsea.navy.deps.mil/wc/surinhd/e/private/vmr/Lists/PPIDBook/Item/displayifs.aspx?ID=4178"
    },
    "PlannedCarryover": 0,
    "TotalProjectedCarryover": 0,
    "ContingentLiabilities": 0,
    "IHDLaborDollars": 0,
    "RASSafety": "Low",
    "RASFunding": "Low",
    "RASCost": "Low",
    "RASSchedule": "Low",
    "RASPerformance": null,
    "RASQuality": "Low",
    "RASResources": "Low",
    "RASOverall": null,
    "SafetyTrendId": null,
    "SafetyEvalId": null,
    "PrevSafetyEvalId": null,
    "SafetyHighlights": null,
    "SoftwareTrendId": null,
    "SoftwareEvalId": null,
    "PrevSoftwareEvalId": null,
    "SoftwareHighlights": null,
    "RebaselineDate": "2014-08-01T04:00:00Z",
    "RebaselineTimes": 0,
    "RebaselineRCCategory": null,
    "RebaselineRootCauseId": null,
    "PrevRebaselineDate": "2014-08-01T04:00:00Z",
    "RASEquipment": "Low",
    "RASFacilities": "Low",
    "RASDocuments": null,
    "RASHardware": null,
    "RASSoftware": null,
    "RASIngredients": null,
    "ProjectLevel": "2 - >=$250k",
    "ProjectReviewDate": "2014-09-16T04:00:00Z",
    "DaysSinceLastProjectReview": 1057,
    "TodaysDate": "2017-08-08T20:06:05Z",
    "ApprovalDateProjectPlan": "2012-10-17T04:00:00Z",
    "ApprovalDateCMPlan": "2012-05-31T04:00:00Z",
    "ApprovalDateWPSheet": "2017-05-22T13:57:00Z",
    "Comments": "Funding has expired as of 12/31/15.  All work is completed.  Project will be closed once contingent liabilities are cleared. \n6/29/16 - attempts are being made to clear the outstanding obligations so the DR can be closed.  These are left over funds from a MIPR to Crane. \n10/25/16 - contingent liabilities have been cleared.  Project will be closed. ",
    "CostEvalCount": "0",
    "ScheduleEvalCount": "0",
    "TechnicalEvalCount": "0",
    "SafetyEvalCount": "0",
    "QualityEvalCount": "0",
    "FundingEvalCount": "0",
    "PeopleEvalCount": "0",
    "EquipmentEvalCount": "0",
    "UpdatedFrom": null,
    "ProjectExecutionStatus": "On-Time",
    "FYExpensed": 0,
    "RASCostTrendId": 2,
    "RASScheduleTrendId": 2,
    "RASTechnicalTrendId": null,
    "RASSafetyTrendId": 2,
    "RASQualityTrendId": 2,
    "RASFundingTrendId": 2,
    "RASPeopleTrendId": 2,
    "RASEquipmentTrendId": 2,
    "RASFacilitiesTrendId": 2,
    "RASDocumentsTrendId": null,
    "RASHardwareTrendId": null,
    "RASSoftwareTrendId": null,
    "RASIngredientsTrendId": null,
    "RASOverallTrendId": null,
    "PrevRASCost": "Low",
    "PrevRASSchedule": "Low",
    "PrevRASTechnical": null,
    "PrevRASSafety": "Low",
    "PrevRASQuality": "Low",
    "PrevRASFunding": "Low",
    "PrevRASPeople": "Low",
    "PrevRASEquipment": "Low",
    "PrevRASFacilities": "Low",
    "PrevRASDocuments": null,
    "PrevRASHardware": null,
    "PrevRASSoftware": null,
    "PrevRASIngredients": null,
    "PrevPlannedFinish": "2015-12-31T05:00:00Z",
    "PrevFundingPlanned": 10668000,
    "EVMRequired": "No",
    "SubProject": "No",
    "CurrentFY": "FY2017",
    "SpendPlanRecordId": 9,
    "SpendPlansLink": {
      "__metadata": {
        "type": "SP.FieldUrlValue"
      },
      "Description": "https://navsea.portal.navy.mil/wc/surinhd/e/private/vmr/Lists/VMSpendPlans/Item/editifs.aspx?ID=9",
      "Url": "https://navsea.navy.deps.mil/wc/surinhd/e/private/vmr/Lists/VMSpendPlans/Item/editifs.aspx?ID=9"
    },
    "TotalProjectedFundsReceived": null,
    "PrevRASOverallTrend": null,
    "ERPDRCount": 1,
    "DocumentsEvalCount": 0,
    "FacilitiesEvalCount": 0,
    "HardwareEvalCount": 0,
    "SoftwareEvalCount": 0,
    "IngredientsEvalCount": 0,
    "OverallEvalCount": 0,
    "FYActualReimb": 0,
    "FYActualDC": 0,
    "FYActualAvailable": 0,
    "FYActualTotal": 0,
    "DashCostVar": null,
    "DashSchedVar": null,
    "DashTechVar": null,
    "DashDocVar": null,
    "DashSafetyVar": null,
    "DashQualityVar": null,
    "DashFundingVar": null,
    "DashPeopleVar": null,
    "DashEquipVar": null,
    "DashFacilitiesVar": null,
    "DashHardwareVar": null,
    "DashSoftwareVar": null,
    "DashIngredientsVar": null,
    "DashCostVarTrend": null,
    "DashSchedVarTrend": null,
    "DashTechVarTrend": null,
    "DashSafetyVarTrend": null,
    "DashQualityVarTrend": null,
    "DashFundingVarTrend": null,
    "DashPeopleVarTrend": null,
    "DashEquipVarTrend": null,
    "DashFacilitiesVarTrend": null,
    "DashRASCostTrend": "→",
    "DashRASScheduleTrend": "→",
    "DashRASTechTrend": null,
    "DashRASDocTrend": null,
    "PriorYearTotalProj": null,
    "PriorYearLaborCO": 0,
    "PriorYearNonLaborCO": null,
    "PriorYearObligationsCO": null,
    "CurrentYearApprovedCO": null,
    "TotalProjectedCarryoverByDept": 0,
    "DashRASQualityTrend": "→",
    "DashRASFundingTrend": "→",
    "DashRASPeopleTrend": "→",
    "DashRASEquipTrend": "→",
    "DashRASFacilitiesTrend": "→",
    "DashRASHardwareTrend": null,
    "DashRASSoftwareTrend": null,
    "DashRASSafetyTrend": "→",
    "DashRASIngredientsTrend": null,
    "CostVariance": null,
    "ScheduleVariance": null,
    "VariancesTotal": null,
    "VariancesActive": null,
    "VariancesCost": null,
    "VariancesSchedule": null,
    "DeptText": "M",
    "ProjectLevelShort": "2",
    "OData__x0057_Y01": "0",
    "OData__x0057_Y02": "0",
    "OData__x0057_Y10": "0",
    "WYTD": "0",
    "WYD": "0",
    "WYE": "0",
    "WYG": "0",
    "WYJP": "0",
    "WYM": "0.02",
    "WYR": "0",
    "RASTechDataPkg": null,
    "RASTechDataPkgTrendId": null,
    "TechDataPkgEvalId": null,
    "TechDataPkgEvalTrendId": null,
    "TechDataPkgHighlights": null,
    "PrevRASTechDataPkg": null,
    "PrevTechDataPkgEvalId": null,
    "TechDataPkgEvalCount": "1",
    "FDALink": {
      "__metadata": {
        "type": "SP.FieldUrlValue"
      },
      "Description": "https://navsea.portal.navy.mil/wc/surinhd/e/private/vmr/Lists/FDAV2ReimbCarryoverArchive2017/AllItems.aspx?View={6F32D33E-B552-40BC-A566-2CBB28D84042}&FilterField1=FY&FilterValue1=2017&FilterField2=PPIDText&FilterValue2=AD94",
      "Url": "https://navsea.navy.deps.mil/wc/surinhd/e/private/vmr/Lists/FDAV2ReimbCarryoverArchive2017/AllItemsOld.aspx?View={6F32D33E-B552-40BC-A566-2CBB28D84042}&FilterField1=FY&FilterValue1=2017&FilterField2=PPIDText&FilterValue2=AD94"
    },
    "TaskMetricsIDId": null,
    "ProjectStatusText": "Completed On-Time",
    "ProjectStatusId": 9,
    "OverdueDate": "2017-08-16T05:00:00Z",
    "ERPDRRow2": null,
    "ERPDRRow3": null,
    "ERPDRRow4": null,
    "CarryInRow1": null,
    "CarryInRow2": null,
    "CarryInRow3": null,
    "NewReimbRow1": 0,
    "NewReimbRow2": null,
    "NewReimbRow3": null,
    "NewDCRow1": 0,
    "NewDCRow2": null,
    "NewDCRow3": null,
    "LinkedUsernamesId": {
      "__metadata": {
        "type": "Collection(Edm.Int32)"
      },
      "results": [
        1289,
        499,
        891,
        119,
        104,
        1378
      ]
    },
    "CarryInRow4": null,
    "NewReimbRow4": null,
    "NewDCRow": null,
    "CurObligationsRow1": null,
    "CurObligationsRow2": null,
    "CurObligationsRow3": null,
    "CurObligationsRow4": null,
    "CurExpensedRow1": null,
    "CurExpensedRow2": null,
    "CurExpensedRow3": null,
    "CurExpensedRow4": null,
    "CostEstimateID": null,
    "WorkOrderID": null,
    "RDTE": "Not RDTE funded",
    "NewRebaselineRootCauseCatId": null,
    "NewRebaselineRootCauseId": null,
    "PrimaryComplexId": 10,
    "TotalBudget": "0",
    "EDWTotalRow1": null,
    "EDWTotalRow2": null,
    "EDWTotalRow3": null,
    "EDWTotalRow4": null,
    "EDWObligRow1": null,
    "EDWObligRow2": null,
    "EDWObligRow3": null,
    "EDWObligRow4": null,
    "EDWExpensedRow1": null,
    "EDWExpensedRow2": null,
    "EDWExpensedRow3": null,
    "EDWExpensedRow4": null,
    "EDWAvailableRow1": null,
    "EDWAvailableRow2": null,
    "EDWAvailableRow3": null,
    "EDWAvailableRow4": null,
    "EDWReportDate": null,
    "SpendPlansLaborId": 112,
    "SpendPlansNonLaborId": 112,
    "ValueMan0": null,
    "SetBaseline": true,
    "PrevSetBaseline": null,
    "DRPlusTitle": "DR-027252-NAMMO TALLEY LAW M72A9",
    "EndUsers": null,
    "Modified_": null,
    "CustomerRDD": null,
    "LotID": null,
    "CategoryId": null,
    "MilestoneId": null,
    "MilestoneSearch": null,
    "PhaseSearch": null,
    "WorkCenterId": null,
    "ID": 6,
    "OData__UIVersionString": "10.0",
    "Attachments": false,
    "GUID": "47443aa9-8a35-4420-9a8e-f48eea884778"
  }
]