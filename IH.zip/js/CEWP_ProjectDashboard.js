﻿var IH = IH || {};
IH.PROJECT = IH.PROJECT || {};

IH.PROJECT.DASHBOARD = function () {
	
	function Init(site) {
		logit('Page Init Complete. Loading Styles');
		loadCSS('https://use.fontawesome.com/releases/v5.7.1/css/all.css');
		loadCSS('https://cdn.jsdelivr.net/npm/bootstrap-vue@2.0.0-rc.12/dist/bootstrap-vue.css');
		loadCSS('https://cdn.jsdelivr.net/npm/element-ui@2.4.11/lib/theme-chalk/index.css');
		loadCSS('https://cdn.jsdelivr.net/npm/dhtmlx-gantt@6.0.7/codebase/dhtmlxgantt.css');
		loadCSS('https://cdn.jsdelivr.net/npm/highcharts@6.0.7/css/highcharts.css');
		loadCSS(site + '/SiteAssets/css/CEWP_ProjectDashboard.css');
		
		loadScripts();
		/*
		loadCSS('https://cdn.jsdelivr.net/npm/bootstrap-vue@2.0.0-rc.12/dist/bootstrap-vue.css', function () {
			loadCSS('https://cdn.jsdelivr.net/npm/element-ui@2.4.11/lib/theme-chalk/index.css', function () {
				loadCSS('https://cdn.jsdelivr.net/npm/dhtmlx-gantt@6.0.7/codebase/dhtmlxgantt.css', function () {
					loadCSS('https://cdn.jsdelivr.net/npm/highcharts@6.0.7/css/highcharts.css', function () {
						loadCSS(site + '/SiteAssets/css/CEWP_ProjectDashboard.css', function () {
							logit('Styles Loaded. Loading Scripts.');
							loadScripts();
						});
					});
				});
			});
		});	
		*/
	}
	
	function loadScripts() {
		loadscript('https://cdn.jsdelivr.net/npm/vue@2.5.21/dist/vue.min.js', function () {
			loadscript('https://cdn.jsdelivr.net/npm/highcharts@6.0.7/highcharts.min.js', function () {
				loadscript('https://cdn.jsdelivr.net/npm/vue-highcharts@0.1.0/dist/vue-highcharts.min.js', function () {
					loadscript('https://cdn.jsdelivr.net/npm/dhtmlx-gantt@6.0.7/codebase/dhtmlxgantt.min.js', function () {
						loadscript('https://cdn.jsdelivr.net/npm/dhtmlx-gantt@6.0.7/codebase/ext/dhtmlxgantt_marker.js', function () {
							loadscript('https://cdn.jsdelivr.net/npm/vuex@3.1.0/dist/vuex.min.js', function () {
								loadscript('https://cdn.jsdelivr.net/npm/bootstrap-vue@2.0.0-rc.12/dist/bootstrap-vue.js', function () {
									loadscript('https://cdn.jsdelivr.net/npm/element-ui@2.4.11/lib/index.js', function () {
										loadscript('https://cdn.jsdelivr.net/npm/element-ui@2.4.11/lib/umd/locale/en.js', function () {
											loadscript(site + '/SiteAssets/js/projectstore.js', function () {
												loadscript(site + '/SiteAssets/js/milestonetabletemplate.js', function () {
													loadscript(site + '/SiteAssets/js/milestonegantttemplate.js', function () {
														loadscript(site + '/SiteAssets/js/projectdashboardcomponents.js', function () {
															logit("All Scripts Loaded");
																				
															new Vue({
																el: '#app',
																store: projectstore,
																components: {
																	'page-layout': PageLayout
																}
															});
														});
													});
												});
											});							
										});							
									});
								});	
							});	
						});					
					});
				});
			});
		});
	}
	
	return {
        Init: Init
    }
}