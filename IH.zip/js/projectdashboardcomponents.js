﻿var SLASH = "/";
var tp1 = new String(window.location.protocol);
var tp2 = new String(window.location.host);
var site = tp1 + SLASH + SLASH + tp2 + _spPageContextInfo.webServerRelativeUrl;

var PageLayoutTemplate = "";
PageLayoutTemplate += "<b-container>";
PageLayoutTemplate += "		<b-modal id='pickermodal' ref='pickermodal' centered title='Select User'>";
PageLayoutTemplate += " 		<b-container fluid>";
PageLayoutTemplate += " 			<div class='peoplepicker' id='peoplepicker'>";
PageLayoutTemplate += "			</b-container>";
PageLayoutTemplate += "			<div slot='modal-footer' class='w-100'>";
PageLayoutTemplate += "				<b-btn size='sm' class='float-right' @click=''>Save</b-btn>";
PageLayoutTemplate += "			</div>";
PageLayoutTemplate += "		</b-modal>";
PageLayoutTemplate += "     <b-row v-if='showMsg' class='text-center'><b-col cols='12'><div class='alert' :class='msgType' role='alert'>{{msg}}</div></b-col></b-row>";
PageLayoutTemplate += "     <b-row class='sectionbody'>";
PageLayoutTemplate += "    		<b-col md='12'>";
PageLayoutTemplate += "     		<b-card no-body>";
PageLayoutTemplate += "                 <b-tabs ref='pdtabs' card @input='tabChanged'>";
PageLayoutTemplate += "                 	<b-tab title='Projects'><projects-by-title></projects-by-title></b-tab>";
PageLayoutTemplate += "                 	<b-tab title='Project Calendar'>COMPONENT</b-tab>";
PageLayoutTemplate += "                 	<b-tab title='Project Gantt'>COMPONENT</b-tab>";
PageLayoutTemplate += "                 	<b-tab title='Milestones By Project'>COMPONENT</b-tab>";
PageLayoutTemplate += "                 	<b-tab title='Milestones By Manager'>COMPONENT</b-tab>";
PageLayoutTemplate += "                 	<b-tab title='Root Causes'>COMPONENT</b-tab>";
PageLayoutTemplate += "                 <b-tabs>";
PageLayoutTemplate += "             </b-card>";
PageLayoutTemplate += "    	    </b-col>";
PageLayoutTemplate += "		</b-row>";
PageLayoutTemplate += "     <b-row v-if='showMsg' class='text-center'><b-col cols='12'><div class='alert' :class='msgType' role='alert'>{{msg}}</div></b-col></b-row>";
PageLayoutTemplate += "</b-container>";

var ByTitleTemplate = "";
ByTitleTemplate += "<b-container fluid>";
ByTitleTemplate += "	<b-row>";
ByTitleTemplate += "    	<b-col cols='12'>";
ByTitleTemplate += "			<b-table ref='bytitletable' show-empty='true' :per-page='pagesize' :current-page='currentpage' :sort-by.sync='sortby' :sort-desc.sync='sortdesc' v-model='shownData' @row-clicked='' responsive :striped='striped' :bordered='bordered' :small='small' :hover='hover' :items='projects' :fields='fields'>";
ByTitleTemplate += "				<template slot='empty'>{{empty}}</template>";
ByTitleTemplate += "				<template slot='actions' slot-scope='row'>";
ByTitleTemplate += "					<project-milestones v-if='row.item.md === \"Y\"' :erpid='row.item.erpid' :project='row.item.title'></project-milestones>";
ByTitleTemplate += "				</template>";
ByTitleTemplate += "			</b-table>"; 
ByTitleTemplate += "			<b-pagination v-model='currentpage' :total-rows='totalrows' :per-page='pagesize'></b-pagination>";
ByTitleTemplate += "    	</b-col>";
ByTitleTemplate += "    </b-row>";
ByTitleTemplate += "</b-container>";

var ProjectMilestonesTemplate = "<div>";
ProjectMilestonesTemplate += "<b-button size='sm' class='smallbutton' @click='showme()' :ref='\"mbtn_\" + erpid' title='Show Milestones'>M</b-button>";
ProjectMilestonesTemplate += "<b-modal id='msmodal' ref='msmodal' size='lg' centered>";
ProjectMilestonesTemplate += " 		<template slot='modal-title'>";
ProjectMilestonesTemplate += " 			<div class='modaltitle'>{{title}}</div>";
ProjectMilestonesTemplate += " 		</template>";
ProjectMilestonesTemplate += " 		<b-container fluid>";
ProjectMilestonesTemplate += "     		<b-card no-body>";
ProjectMilestonesTemplate += "          	<b-tabs ref='mstabs' v-model='tabIndex' card @input='tabChanged'>";
ProjectMilestonesTemplate += "                 	<b-tab title='Table View'>";
ProjectMilestonesTemplate += "						<milestone-table :erpid='erpid' :project='project'></milestone-table>";
ProjectMilestonesTemplate += "					</b-tab>";
ProjectMilestonesTemplate += "                 	<b-tab>";
ProjectMilestonesTemplate += "						<template slot='title'>Gantt View</template>";
ProjectMilestonesTemplate += "						<milestone-gantt :erpid='erpid' :project='project' :clicked='tabClicked'></milestone-gantt>";
ProjectMilestonesTemplate += "					</b-tab>";
ProjectMilestonesTemplate += "				</b-tabs>";
ProjectMilestonesTemplate += "     		</b-card>";		
ProjectMilestonesTemplate += "		</b-container>";
ProjectMilestonesTemplate += "		<div slot='modal-footer' class='modalfooterslot'></div>";
ProjectMilestonesTemplate += "</b-modal></div>";

var ProjectMilestones = {
	template: ProjectMilestonesTemplate,
	data: function () {
		return {
			title: '',
			tabIndex: 0,
			tabClicked: false
		}
	},
	components: {
        'milestone-table': MilestoneTable,
        'milestone-gantt': MilestoneGantt
    },
    props: [
    	'erpid',
    	'project'
    ],
    created: function () {
    	//logit("Created button for erpid " + this.erpid);
    },
    updated: function () {
    	//this.updateMilestones();
    },
    mounted: function () {
    	//this.gantt = gantt;
    },
    methods: {
    	showme: function () {
    		this.title = "Milestones for " + this.project;
    		this.$refs['msmodal'].show();
    	},
    	getID: function (text, id) {
        	return text + "_" + id;
        },
        tabChanged: function () {
        	if (this.tabIndex === 1) {
        		//this.tabClicked = true;
        		this.$root.$emit('ganttshown', this.erpid);
        	}
        	else {
        		this.tabClicked = false;
        	}
        }
	}
}

var ProjectsByTitle = {
	template: ByTitleTemplate,
	components: {
        'project-milestones': ProjectMilestones,
    },
	data: function () {
		return {
			projectdata: [],
			showMsg: true,
            msgType: 'alert-info',
            items: [], // array for the table
			striped: true,
      		bordered: true,
      		outlined: true,
      		small: true,
      		hover: true,
      		dark: false,
      		fixed: false,
      		footClone: false,
      		sortby: 'erpid',
      		sortdesc: false,
      		pagesize: 30,
      		currentpage: 1,
      		totalrows: 0,
      		fields: [
      			{ key: 'actions', label: 'Actions', thClass: 'text-center'},
      			{ key: 'title', label: 'Project Title', sortable: true, thClass: 'text-center', tdClass: 'text-left'},
      			{ key: 'erpid', label: 'ERP ID', sortable: true, thClass: 'text-center'},
      			{ key: 'ppid', label: 'PPID', sortable: true, thClass: 'text-center'},
      			{ key: 'wid', label: 'Work Order', thClass: 'text-center'},
      			{ key: 'dept', label: 'Dept', thClass: 'text-center'},
      			{ key: 'div', label: 'Div', thClass: 'text-center'},
      			{ key: 'pjm', label: 'PjM', thClass: 'text-center'},
      			{ key: 'manager', label: 'Manager', sortable: true, thClass: 'text-center'},
      			{ key: 'status', label: 'Status', sortable: true, thClass: 'text-center'},
      			{ key: 'pstart', label: 'Plan Start', sortable: true, thClass: 'text-center'},
      			{ key: 'astart', label: 'Act Start', thClass: 'text-center'},
      			{ key: 'pfinish', label: 'Plan Finish', thClass: 'text-center'},
      			{ key: 'afinish', label: 'Act Finish', thClass: 'text-center'},
      		],
      		shownData: [], // Will be the milestone and deilverables array used for the table
			empty: "Getting Projects. Please Wait..."
		}
	},
	computed: {
		...Vuex.mapState(["projects", "message"]),
	},
	updated: function () {
		if (this.projects.length && this.projects.length > 0) {
			this.updateTable();
			this.showMsg = false;
		}
		var stop = stop;
    },
	methods: {
		updateTable: function () {
			this.items = this.projects;
			this.totalrows = this.items.length;
		},
		getID: function (text, id) {
        	return text + "_" + id;
        }
	}
}

var PageLayout = {
    template: PageLayoutTemplate,
    data: function () {
        return {
        	tempdata: [], // Holds the projects while fetching data. If there are more than the REST threshold the function loops until all are loaded.
        	showMsg: false,
            msgType: 'alert-info',
        	msg: ''        
        }
    },
    created: function () {
        this.getProjectData(null);
    },
    mounted: function () {
    	this.$nextTick(function () {
			logit("DASHBOARD MOUNTED");
    	})
    },
    methods: {
        getProjectData: function (murl) {
        	if (murl === null) {
	        	murl = site + "/_api/lists/getbytitle('ProjectExecutionMain')/items?";
	        	murl += "$select=Title,ProjectTitle,DeptText,PlannedStart,ActualStart,PlannedFinish,ActualFinish,Status,WorkOrderID,ProjectStatusText,ProjectLevelShort,SpendPlanRecord/Title,VarianceEditRecord/Title,DeliverableMilestonesEditRecord/Title,PPID/Title,PM/Title,PjMCode/Title,PjMCode/Branch,PjMCode/Div,CA/Title,ERPResourceSponsor/Title";	        	
	        	murl += "&$expand=PPID,PM,PjMCode,CA,ERPResourceSponsor,DeliverableMilestonesEditRecord,VarianceEditRecord,SpendPlanRecord"; // DeliverableMilestonesEditRecord is Y if there are milestones
	        }

            var vm = this;
            jQuery.ajax({
                url: murl,
                method: "GET",
                headers: { 'accept': 'application/json; odata=verbose' },
                error: function (jqXHR, textStatus, errorThrown) {
                    logit("Error Status: " + textStatus + ":: errorThrown: " + errorThrown);
                },
                success: function (data) {
                	vm.tempdata = vm.tempdata.concat(data.d.results);
                	if (data.d.__next) {
                		murl = data.d.__next;
                		vm.getProjectData(murl);
                	}
                	else {
                		var j = jQuery.parseJSON(JSON.stringify(vm.tempdata));
                		var p = [];
                		// just loop and create the array with better keys
                		for (var i = 0; i < j.length; i++) {
                			p.push({
                				'title': j[i]['ProjectTitle'],
      							'erpid': j[i]['Title'],
      							'ppid': j[i]['PPID']['Title'],
      							'wid': j[i]['WorkOrderID'],
      							'dept': j[i]['DeptText'],
      							'div': j[i]['PjMCode']['Div'],
      							'pjm': j[i]['PjMCode']['Branch'],
      							'manager': j[i]['PM']['Title'],
      							'status': j[i]['Status'],
      							'pstart': moment(j[i]['PlannedStart']).isValid() ? moment(j[i]['PlannedStart']).format('MM/DD/YYYY') : '',
      							'astart': moment(j[i]['ActualStart']).isValid() ? moment(j[i]['ActualStart']).format('MM/DD/YYYY') : '',
      							'pfinish': moment(j[i]['PlannedFinish']).isValid() ? moment(j[i]['PlannedFinish']).format('MM/DD/YYYY') : '',
      							'afinish': moment(j[i]['ActualFinish']).isValid() ? moment(j[i]['ActualFinish']).format('MM/DD/YYYY') : '',
      							'md': j[i]['DeliverableMilestonesEditRecord']['Title']
                			});
                		}
                		var stop = 'stop';
                		vm.$store.dispatch("loadProjects", p);
                		stop = 'stop';
					}
                } 
            });
        },
        formatDate: function (d) {
            return d === null ? "" : moment(d).format("MM/DD/YYYY");
        },
        tabChanged: function (idx) {
        	logit('Tab index: ' + idx);
        	var stop = "stop";
        }
    },
    components: {
        'projects-by-title': ProjectsByTitle,
    }
}
