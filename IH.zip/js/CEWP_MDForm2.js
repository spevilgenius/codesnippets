﻿var IH = IH || {};
IH.MDFORM = IH.MDFORM || {};

IH.MDFORM.Home = function () {
	function Init(site) {
		console.log('Page Init Complete');
		//loadCSS('https://use.fontawesome.com/releases/v5.7.1/css/all.css');
		loadCSS('https://cdn.jsdelivr.net/npm/bootstrap-vue@2.0.0-rc.11/dist/bootstrap-vue.css');
		loadCSS('https://cdn.jsdelivr.net/npm/element-ui@2.4.11/lib/theme-chalk/index.css');
		loadCSS(site + '/SiteAssets/css/CEWP_MDForm2.css');
		
		loadscript('https://cdn.jsdelivr.net/npm/vue@2.5.21/dist/vue.min.js', function () {
				loadscript('https://cdn.jsdelivr.net/npm/bootstrap-vue@2.0.0-rc.11/dist/bootstrap-vue.js', function () {
					loadscript(site + '/_layouts/15/autofill.js', function () {
						loadscript(site + '/_layouts/15/clienttemplates.js', function () {
							loadscript(site + '/_layouts/15/clientforms.js', function () {
								loadscript(site + '/_layouts/15/clientpeoplepicker.js', function () {
									loadscript('https://cdn.jsdelivr.net/npm/element-ui@2.4.11/lib/index.js', function () {
										loadscript('https://cdn.jsdelivr.net/npm/element-ui@2.4.11/lib/umd/locale/en.js', function () {
											loadscript(site + '/SiteAssets/js/mdformcomponents2.js', function () {
												logit("All Scripts Loaded");
												new Vue({
									                el: '#app',
									                components: {
									                    'page-layout': PageLayout
									                }
									            });
											});							
										});							
									});
								});							
							});
						});							
					});
				});

		});
	
	}
	
	return {
        Init: Init
    }
}