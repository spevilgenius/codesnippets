﻿var MilestoneTableTemplate = "";
MilestoneTableTemplate += "<b-table show-empty='true' :per-page='pagesize' :current-page='currentpage' v-model='msData' responsive :striped='striped' :bordered='bordered' :small='small' :hover='hover' :items='milestones' :fields='fields'>";
MilestoneTableTemplate += "		<template slot='empty'>{{empty}}</template>";
MilestoneTableTemplate += "		<template slot='title' slot-scope='item'>";
MilestoneTableTemplate += "         <div class='title' v-bind:id='getID(\"Title\", msData[item.index].ID)'>{{msData[item.index].title}}</div>";
MilestoneTableTemplate += "		</template>";
MilestoneTableTemplate += "		<template slot='dl' slot-scope='item'>";
MilestoneTableTemplate += "         <div class='dl' v-bind:id='getID(\"DaysLate\", msData[item.index].ID)'>{{msData[item.index].dl}}</div>";
MilestoneTableTemplate += "		</template>";
MilestoneTableTemplate += "	</b-table>";
MilestoneTableTemplate += "	<b-pagination v-model='currentpage' :total-rows='totalrows' :per-page='pagesize'></b-pagination><div>";

var MilestoneTable = {
	template: MilestoneTableTemplate,
	data: function () {
		return {
			striped: true,
      		bordered: true,
      		small: true,
      		hover: true,
      		sortby: 'erpid',
      		sortdesc: false,
      		pagesize: 30,
      		currentpage: 1,
      		totalrows: 0, 		
		    empty: "Getting Milestones. Please Wait...",
      		title: '',
      		mstd: [],  // tempdata while querying milestones. Used to recursively load milestones.
      		milestones: [],
      		msData: [], // Will be the milestone and deilverables array used for the table
			fields: [
				{ key: 'order', label: 'Order', thClass: 'text-center'},
      			{ key: 'cp', label: 'CP', thClass: 'text-center'},
      			{ key: 'cd', label: 'CD', thClass: 'text-center'},
      			{ key: 'title', label: 'Milestone Title', thClass: 'text-center', tdClass: 'left-sticky'},
      			{ key: 'delid', label: 'Deliverable ID', thClass: 'text-center'},
      			{ key: 'msps', label: 'MS Planned Start', thClass: 'text-center msheader'},
      			{ key: 'msas', label: 'MS Actual Start', thClass: 'text-center msheader'},
      			{ key: 'mdplf', label: 'MD Planned Finish', thClass: 'text-center msheader'},
      			{ key: 'mdprf', label: 'MD Projected Finish', thClass: 'text-center msheader'},
      			{ key: 'mdaf', label: 'MD Actual Finish', thClass: 'text-center msheader'},
      			{ key: 'pcomp', label: '% Comp', thClass: 'text-center msheader'},
      			{ key: 'duration', label: 'Duration', thClass: 'text-center msheader'},
      			{ key: 'pqty', label: 'Planned Qty', thClass: 'text-center mdheader'},
      			{ key: 'aqty', label: 'Actual Qty', thClass: 'text-center mdheader'},
      			{ key: 'oqty', label: 'OnTime Qty', thClass: 'text-center mdheader'},
      			{ key: 'units', label: 'Units', thClass: 'text-center mdheader'},
      			{ key: 'status', label: 'Milestone Status', thClass: 'text-center'},
      			{ key: 'pff', label: 'Project Phase Filter', thClass: 'text-center'},
      			{ key: 'mf', label: 'MD Filter', thClass: 'text-center'},
      			{ key: 'leadwc', label: 'Lead WC', thClass: 'text-center'},
      			{ key: 'lead', label: 'Milestone Lead', thClass: 'text-center'},
      			{ key: 'cpwc', label: 'CP WC', thClass: 'text-center'},
      			{ key: 'dl', label: 'Days Late', thClass: 'text-center'},
      			{ key: 'comms', label: 'Comments', thClass: 'text-center'},
      			{ key: 'rcc', label: 'Root Cause Category', thClass: 'text-center'},
      			{ key: 'rc', label: 'Root Cause', thClass: 'text-center'}
			]
      	}
    },
    props: [
    	'erpid',
    	'project'
    ],
    created: function () {
    	//logit("Created button for erpid " + this.erpid);
    	this.getMAD(null);
    },
    updated: function () {
    	this.updateMilestones();
    },
    methods: {
    	getID: function (text, id) {
        	return text + "_" + id;
        },
    	updateMilestones: function () {
			if (this.milestones.length > 0) {
				this.updateCalcs();
				this.mstd.length = 0;
			}
		},
		getMAD: function (murl) {
    		if (murl === null) {
    			murl = site + "/_api/lists/getbytitle('MilestonesAndDeliverables')/items?";
	        	murl += "$select=*,MileStoneLead/Title,MileStoneLead/ID,MileStoneLead/Name";
	        	murl += "&$orderby=MilestoneOrder&$expand=MileStoneLead";
	            murl += "&$filter=(ERPID eq '" + this.erpid + "')";
	        }
    	
    		var vm = this;
            jQuery.ajax({
                url: murl,
                method: "GET",
                headers: { 'accept': 'application/json; odata=verbose' },
                error: function (jqXHR, textStatus, errorThrown) {
                    logit("Error Status: " + textStatus + ":: errorThrown: " + errorThrown);
                },
                success: function (data) {
                	vm.mstd = vm.mstd.concat(data.d.results);
                	if (data.d.__next) {
                		murl = data.d.__next;
                		vm.getMAD(murl);
                	}
                	else {
                		var j = jQuery.parseJSON(JSON.stringify(vm.mstd));
                		vm.parseMilestoneData(j);
                	}
                }
            });
    	},
    	parseMilestoneData: function (j) {
			if (j.length > 0) {
    			this.totalrows = j.length;
        		for (var i = 0; i < j.length; i++) {
        			this.milestones.push({
        				ID: j[i]["ID"],
        				order: i + 1,
        				cp: j[i]["CriticalPath"],
        				cd: j[i]["CustomerDeliverable"],
        				title: j[i]["Title"],
						delid: j[i]["DeliverableID"],
						msps: moment(j[i]["PlannedStart"]).isValid() ? moment(j[i]["PlannedStart"]).format('MM/DD/YYYY') : '',
						msas: moment(j[i]["ActualStart"]).isValid() ? moment(j[i]["ActualStart"]).format('MM/DD/YYYY') : '',
						mdplf: moment(j[i]["PlannedFinish"]).isValid() ? moment(j[i]["PlannedFinish"]).format('MM/DD/YYYY') : '',
						mdprf: moment(j[i]["ProjectedFinish"]).isValid() ? moment(j[i]["ProjectedFinish"]).format('MM/DD/YYYY') : '',
						mdaf: moment(j[i]["ActualFinish"]).isValid() ? moment(j[i]["ActualFinish"]).format('MM/DD/YYYY') : '',      							
						duration: j[i]["Duration"],
						pcomp: j[i]["PercentComplete"],
						pqty: j[i]["PlannedQuantity"],
						aqty: j[i]["ActualQuantity"],
						oqty: j[i]["OnTimeQuantity"],
						units: j[i]["Units"],
						status: j[i]["Status"],
						rcc: j[i]["RootCauseCategory"],
						rc: j[i]["RootCause"],      							
						pff: j[i]["Phase"],
						mf: j[i]["Category"],
						leadwc: j[i]["LeadWC"],
						lead: j[i]["MileStoneLead"]['Name'],
						leadid: j[i]["MileStoneLead"]['ID'],
						leadtitle: j[i]["MileStoneLead"]['Title'],
						cpwc: j[i]["CPWC"],
						dl: 0,
						comms: j[i]["Comments"]
        			});
        		}
        		this.updateCalcs();
				this.mstd.length = 0;
    		}
		},
    	updateCalcs : function () {
    		for (var i = 0; i < this.milestones.length; i++) {
				// complete
				if (this.milestones[i].mdaf !== '') { 
					// was it late? Must have at least a planned start or actual start. This is actually calculated by dayslate.js and copied here.
					var a, dl = 0;
    				var today = moment();
    				var projfd = this.milestones[i].mdprf;
        			var planfd = this.milestones[i].mdplf;
    				var afd = this.milestones[i].mdaf;

					if (afd !== undefined && afd !== 'undefined' && afd !== '') { // There is an actual finish date so use it instead of today
	    				if (planfd !== undefined || planfd !== '') { // Use these dates to determine how late it was
	    					a = moment(afd);
            				a.add(a.utcOffset() * -1, 'm');
            				b = moment(planfd);
            				dl = a.diff(b, 'days');
            			}
            			else { 
            				if (projfd !== undefined && projfd !== '') { // Use these dates to determine how late it was
	    						a = moment(afd);
            					a.add(a.utcOffset() * -1, 'm');
            					b = moment(planfd);
            					dl = a.diff(b, 'days');
            				}
            				else { // Can't calculate if there is no projected or planned finish date
            					dl= -9999;
            				}
            			}
	    			}
	    			else {
	    				if (planfd !== undefined && planfd !== '') { // There is a planned finish date so use it first
	    					a = moment(planfd);
            				a.add(a.utcOffset() * -1, 'm');
            				dl = today.diff(a, 'days');
	    				}
	    				else { 	    		
	    					if (projfd !== undefined && projfd !== '') { // Use these dates to determine how late it was
	    						a = moment(projfd);
            					a.add(a.utcOffset() * -1, 'm');
            					dl = today.diff(a, 'days');
            				}
            				else { // Can't calculate if there is no projected or planned finish date
            					dl= -9999;
            				}
	    				}
	    			}
	    			
	    			switch (true) {
	    				case dl === -9999:
	        				this.milestones[i].dl = "NA";
	        				jQuery("#Title_" + this.milestones[i].ID).parent().parent().removeClass('table-rootcause'); // just in case it was applied
	        				break;

	    				case dl < 0:
	        				this.milestones[i].dl = dl;
	        				jQuery("#Title_" + this.milestones[i].ID).parent().parent().removeClass('table-rootcause'); // just in case it was applied
	        				// format for not late
	        				break;
	
	    				case dl == 0:
	        				this.milestones[i].dl = dl;
	        				jQuery("#Title_" + this.milestones[i].ID).parent().parent().removeClass('table-rootcause'); // just in case it was applied
            				// formate for done today?
	        				break;
	
	    				case dl > 0:
	        				this.milestones[i].dl = dl;
	        				jQuery("#DaysLate_" + this.milestones[i].ID).addClass('islate');
            				// format for late and prompt for root cause
            				var el = "Title_" + this.milestones[i].ID;
            				if (this.milestones[i].rcc === null || this.milestones[i].rc === null) { 
            					jQuery("#" + el).parent().parent().addClass('table-rootcause');
            				}
            				else {
            					jQuery("#" + el).parent().parent().removeClass('table-rootcause');
            				}
	        				break;
					}
				}				
			}
    	}
    }
}
