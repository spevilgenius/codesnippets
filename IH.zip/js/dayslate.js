﻿var errorcontainer = "ErrorContainer";

(function () {
    if (typeof SPClientTemplates === 'undefined') return;
    var DaysLateCTX = {};
    DaysLateCTX.Templates = {};
    DaysLateCTX.Templates.Fields = {
        'DaysLate': {
            'View': DLView,
            'DisplayForm': DLDisplay,
            'EditForm': DLEdit,
            'NewForm': DLNew
        }
    };
    SPClientTemplates.TemplateManager.RegisterTemplateOverrides(DaysLateCTX);
})();

function RegisterCallBacks(formCtx) {
    formCtx.registerInitCallback(formCtx.fieldName, function () {
        // var dlInput = document.getElementById("txtDaysLate");
    });

    formCtx.registerGetValueCallback(formCtx.fieldName, function () {
        var a, dl = 0;
    	var today = moment();
    	var projfd = ctx.CurrentItem.ProjectedFinish;
        var planfd = ctx.CurrentItem.PlannedFinish;
    	var afd = ctx.CurrentItem.ActualFinish;
        // console.log('INFO: ' + today + ", " + pfd + ", " + afd);

		if (afd !== undefined && afd !== 'undefined' && afd !== '') { // There is an actual finish date so use it instead of today
	    	if (planfd !== undefined || planfd !== '') { // Use these dates to determine how late it was
	    		a = moment(afd);
            	a.add(a.utcOffset() * -1, 'm');
            	b = moment(planfd);
            	dl = a.diff(b, 'days');
            }
            else { 
            	if (projfd !== undefined && projfd !== '') { // Use these dates to determine how late it was
	    			a = moment(afd);
            		a.add(a.utcOffset() * -1, 'm');
            		b = moment(planfd);
            		dl = a.diff(b, 'days');
            	}
            	else { // Can't calculate if there is no projected or planned finish date
            		dl= -9999;
            	}
            }
	    }
	    else {
	    	if (planfd !== undefined && planfd !== '') { // There is a planned finish date so use it first
	    		a = moment(planfd);
            	a.add(a.utcOffset() * -1, 'm');
            	dl = today.diff(a, 'days');
	    	}
	    	else { 	    		
	    		if (projfd !== undefined && projfd !== '') { // Use these dates to determine how late it was
	    			a = moment(projfd);
            		a.add(a.utcOffset() * -1, 'm');
            		dl = today.diff(a, 'days');
            	}
            	else { // Can't calculate if there is no projected or planned finish date
            		dl= -9999;
            	}
	    	}
	    }
		return dl;
    });

    var validators = new SPClientForms.ClientValidation.ValidatorSet();

    if (formCtx.fieldSchema.Required) {
        validators.RegisterValidator(new SPClientForms.ClientValidation.RequiredValidator());
    }

    if (validators._registeredValidators.length > 0) {
        formCtx.registerClientValidator(formCtx.fieldName, validators);
    }

    formCtx.registerValidationErrorCallback(formCtx.fieldName, function (errorResult) {
        SPFormControl_AppendValidationErrorMessage(errorcontainer, errorResult);
    });
}

function DLEdit(ctx) {
    return RenderExistingValues(ctx);
}

function DLNew(ctx) {
    var html = "<input id='txtDaysLate' disabled='disabled' placeholder='Calculated Later'/>";    
    return html;
}

function RenderExistingValues(ctx) {
    var a, dl = 0;
    var today = moment();
    var projfd = ctx.CurrentItem.ProjectedFinish;
    var planfd = ctx.CurrentItem.PlannedFinish;
    var afd = ctx.CurrentItem.ActualFinish;
        // console.log('INFO: ' + today + ", " + pfd + ", " + afd);

	var html = "";
	if (afd !== undefined && afd !== 'undefined' && afd !== '') { // There is an actual finish date so use it instead of today
	    	if (planfd !== undefined || planfd !== '') { // Use these dates to determine how late it was
	    		a = moment(afd);
            	a.add(a.utcOffset() * -1, 'm');
            	b = moment(planfd);
            	dl = a.diff(b, 'days');
            }
            else { 
            	if (projfd !== undefined && projfd !== '') { // Use these dates to determine how late it was
	    			a = moment(afd);
            		a.add(a.utcOffset() * -1, 'm');
            		b = moment(planfd);
            		dl = a.diff(b, 'days');
            	}
            	else { // Can't calculate if there is no projected or planned finish date
            		dl= -9999;
            	}
            }
	    }
	    else {
	    	if (planfd !== undefined && planfd !== '') { // There is a planned finish date so use it first
	    		a = moment(planfd);
            	a.add(a.utcOffset() * -1, 'm');
            	dl = today.diff(a, 'days');
	    	}
	    	else { 	    		
	    		if (projfd !== undefined && projfd !== '') { // Use these dates to determine how late it was
	    			a = moment(projfd);
            		a.add(a.utcOffset() * -1, 'm');
            		dl = today.diff(a, 'days');
            	}
            	else { // Can't calculate if there is no projected or planned finish date
            		dl= -9999;
            	}
	    	}
	    }
	    
	    
	switch (true) {
	    case dl === -9999:
	        html += '<div class="dlna" title="No valid dates. Needs at lease a Projected Finish Date">NA</div>';
	        break;

	    case dl < 0:
	        html += '<div class="dllt0">' + dl + '</div>';
	        break;
	
	    case dl == 0:
	        html += '<div class="dleq0">' + dl + '</div>';            
	        break;
	
	    case dl > 0:
	        html += '<div class="dlgt0">' + dl + '</div>';            
	        break;
	}
	    
	return html;
}

function DLView(ctx) {
    if (ctx != null && ctx.CurrentItem != null) {
    	var a, b, dl = 0;
        var today = moment();
        var projfd = ctx.CurrentItem.ProjectedFinish;
        var planfd = ctx.CurrentItem.PlannedFinish;
        var afd = ctx.CurrentItem.ActualFinish;

	    var html = "";
	    if (afd !== undefined && afd !== 'undefined' && afd !== '') { // There is an actual finish date so use it instead of today
	    	if (planfd !== undefined || planfd !== '') { // Use these dates to determine how late it was
	    		a = moment(afd);
            	a.add(a.utcOffset() * -1, 'm');
            	b = moment(planfd);
            	dl = a.diff(b, 'days');
            }
            else { 
            	if (projfd !== undefined && projfd !== '') { // Use these dates to determine how late it was
	    			a = moment(afd);
            		a.add(a.utcOffset() * -1, 'm');
            		b = moment(planfd);
            		dl = a.diff(b, 'days');
            	}
            	else { // Can't calculate if there is no projected or planned finish date
            		dl= -9999;
            	}
            }
	    }
	    else {
	    	if (planfd !== undefined && planfd !== '') { // There is a planned finish date so use it first
	    		a = moment(planfd);
            	a.add(a.utcOffset() * -1, 'm');
            	dl = today.diff(a, 'days');
	    	}
	    	else { 	    		
	    		if (projfd !== undefined && projfd !== '') { // Use these dates to determine how late it was
	    			a = moment(projfd);
            		a.add(a.utcOffset() * -1, 'm');
            		dl = today.diff(a, 'days');
            	}
            	else { // Can't calculate if there is no projected or planned finish date
            		dl= -9999;
            	}
	    	}
	    }
			   
	    switch (true) {
	    	case dl === -9999:
	        	html += '<div class="dlna" title="No valid dates. Needs at lease a Projected Finish or Planned Finish Date">NA</div>';
	            break;

	        case dl < 0:
	        	html += '<div class="dllt0">' + dl + '</div>';
	            break;
	
	        case dl == 0:
	            html += '<div class="dleq0">' + dl + '</div>';            
	            break;
	
	        case dl > 0:
	            html += '<div class="dlgt0">' + dl + '</div>';            
	            break;
	    }
	    
	    return html;
    }
    else {
        return 'No values stored';
    }
}

function DLDisplay(ctx) {
    if (ctx != null && ctx.CurrentItem != null) {
        var a, dl = 0;
        var today = moment();
        var projfd = ctx.CurrentItem.ProjectedFinish;
        var planfd = ctx.CurrentItem.PlannedFinish;
        var afd = ctx.CurrentItem.ActualFinish;
        // console.log('INFO: ' + today + ", " + pfd + ", " + afd);

	    var html = "";
	    if (afd !== undefined && afd !== 'undefined' && afd !== '') { // There is an actual finish date so use it instead of today
	    	if (planfd !== undefined || planfd !== '') { // Use these dates to determine how late it was
	    		a = moment(afd);
            	a.add(a.utcOffset() * -1, 'm');
            	b = moment(planfd);
            	dl = a.diff(b, 'days');
            }
            else { 
            	if (projfd !== undefined && projfd !== '') { // Use these dates to determine how late it was
	    			a = moment(afd);
            		a.add(a.utcOffset() * -1, 'm');
            		b = moment(planfd);
            		dl = a.diff(b, 'days');
            	}
            	else { // Can't calculate if there is no projected or planned finish date
            		dl= -9999;
            	}
            }
	    }
	    else {
	    	if (planfd !== undefined && planfd !== '') { // There is a planned finish date so use it first
	    		a = moment(planfd);
            	a.add(a.utcOffset() * -1, 'm');
            	dl = today.diff(a, 'days');
	    	}
	    	else { 	    		
	    		if (projfd !== undefined && projfd !== '') { // Use these dates to determine how late it was
	    			a = moment(projfd);
            		a.add(a.utcOffset() * -1, 'm');
            		dl = today.diff(a, 'days');
            	}
            	else { // Can't calculate if there is no projected or planned finish date
            		dl= -9999;
            	}
	    	}
	    }
	    
	    
	    switch (true) {
	    	case dl === -9999:
	        	html += '<div class="dlna" title="No valid dates. Needs at lease a Projected Finish Date">NA</div>';
	            break;

	        case dl < 0:
	        	html += '<div class="dllt0">' + dl + '</div>';
	            break;
	
	        case dl == 0:
	            html += '<div class="dleq0">' + dl + '</div>';            
	            break;
	
	        case dl > 0:
	            html += '<div class="dlgt0">' + dl + '</div>';            
	            break;
	    }
	    
	    return html;    
	}
    else {
        return 'No value stored';
    }
}
