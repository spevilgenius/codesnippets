﻿var projectstore = new Vuex.Store({
	state: {
		projects: [],
		message: 'Getting Projects. Please wait...'
	},
	mutations: {
		MUTATE_PROJECTS: function (state, projects) {
			state.projects = projects;
		},
		MUTATE_MESSAGE: function (state, message) {
			state.message = message;
		}
	},
	actions: {
		loadProjects: function (context, projects) {
			context.commit("MUTATE_PROJECTS", projects);
			context.commit("MUTATE_MESSAGE", "Projects Updated");
		}
	},
	getters: {
		projects: function(state) {
			return state.projects;
		}
	}
});