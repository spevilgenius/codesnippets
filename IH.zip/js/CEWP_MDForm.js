﻿var IH = IH || {};
IH.MDFORM = IH.MDFORM || {};

IH.MDFORM.Home = function () {
	function loadCSS(url) {
	    var head = document.getElementsByTagName('head')[0];
	    var style = document.createElement('link');
	    style.type = 'text/css';
	    style.rel = 'stylesheet';
	    style.href = url;
	    head.appendChild(style);
	    //logit("CSS File Loaded: " + url);
	}

	function loadscript(url, callback) {
	    var script = document.createElement("script")
	    script.type = "text/javascript";
	    if (script.readyState) {  //IE
	        script.onreadystatechange = function () {
	            if (script.readyState == "loaded" ||
	                    script.readyState == "complete") {
	                script.onreadystatechange = null;
	                callback();
	            }
	        };
	    } else {  //Others
	        script.onload = function () {
	            callback();
	        };
	    }
	    script.src = url;
	    document.documentElement.insertBefore(script, document.documentElement.firstChild);
	}

	
	function Init(site) {
		console.log('Page Init Complete');
		loadCSS('https://cdn.jsdelivr.net/npm/bootstrap@4.2.1/dist/css/bootstrap.min.css');
		loadCSS('https://cdn.jsdelivr.net/npm/element-ui@2.4.11/lib/theme-chalk/index.css');
		loadCSS('https://cdn.jsdelivr.net/npm/rangeslider.js@2.3.2/dist/rangeslider.min.css');
		loadCSS(site + '/SiteAssets/css/CEWP_MDForm.css');
		
		//loadscript('https://cdn.jsdelivr.net/npm/jquery@3.2.1/dist/jquery.min.js', function () {
			loadscript('https://cdn.jsdelivr.net/npm/rangeslider.js@2.3.2/dist/rangeslider.min.js', function () {
				loadscript('https://cdn.jsdelivr.net/npm/vue@2.5.21/dist/vue.min.js', function () {
					//loadscript('https://cdn.jsdelivr.net/npm/moment@2.23.0/min/moment.min.js', function () {
						loadscript('https://cdn.jsdelivr.net/npm/bootstrap-vue@2.0.0-rc.11/dist/bootstrap-vue.js', function () {
							loadscript(site + '/_layouts/15/autofill.js', function () {
								loadscript(site + '/_layouts/15/clienttemplates.js', function () {
									loadscript(site + '/_layouts/15/clientforms.js', function () {
										loadscript(site + '/_layouts/15/clientpeoplepicker.js', function () {
											loadscript('https://cdn.jsdelivr.net/npm/element-ui@2.4.11/lib/index.js', function () {
												loadscript('https://cdn.jsdelivr.net/npm/element-ui@2.4.11/lib/umd/locale/en.js', function () {
													loadscript(site + '/SiteAssets/js/ihutilities.js', function () {
														loadscript(site + '/SiteAssets/js/mdformcomponents.js', function () {
															logit("All Scripts Loaded");
															new Vue({
												                el: '#app',
												                components: {
												                    'page-layout': PageLayout
												                }
												            });
														});							
													});
												});							
											});
										});							
									});
								});							
							});
						});
					//});
				});
			});
		//});	
	}
	
	return {
        Init: Init
    }
}