﻿var SLASH = "/";
var tp1 = new String(window.location.protocol);
var tp2 = new String(window.location.host);
var site = tp1 + SLASH + SLASH + tp2 + _spPageContextInfo.webServerRelativeUrl;

ELEMENT.locale(ELEMENT.lang.en);

var PageLayoutTemplate = "";
PageLayoutTemplate += "<b-container>";
PageLayoutTemplate += "		<b-modal id='pickermodal' ref='pickermodal' centered title='Select User'>";
PageLayoutTemplate += " 		<b-container fluid>";
PageLayoutTemplate += " 			<div class='peoplepicker' id='peoplepicker'>";
PageLayoutTemplate += "			</b-container>";
PageLayoutTemplate += "			<div slot='modal-footer' class='w-100'>";
PageLayoutTemplate += "				<b-btn size='sm' class='float-right' @click='userselected'>Save</b-btn>";
PageLayoutTemplate += "			</div>";
PageLayoutTemplate += "		</b-modal>";

PageLayoutTemplate += "		<b-modal id='causemodal' ref='causemodal' centered title='Select Root Cause and Category'>";
PageLayoutTemplate += " 		<b-container fluid>";
PageLayoutTemplate += "             <table><tr><td>Root Cause Category</td><td>Root Cause</td></tr><tr>";
PageLayoutTemplate += "             	<td><b-form-select class='causecat' @change='causecatchanged' v-bind:options='causecats' id='ddcausecatmodal'></b-form-select></td>";
PageLayoutTemplate += "             	<td><b-form-select class='cause' @change='causechanged' v-bind:options='causefilter' id='ddcausemodal'></b-form-select></td>";
PageLayoutTemplate += "             </table>";
PageLayoutTemplate += "			</b-container>";
PageLayoutTemplate += "			<div slot='modal-footer' class='w-100'>";
PageLayoutTemplate += "				<b-btn size='sm' class='float-right' @click='causeselected'>Save</b-btn>";
PageLayoutTemplate += "			</div>";
PageLayoutTemplate += "		</b-modal>";

PageLayoutTemplate += "     <b-row v-if='showMsg' class='text-center'><b-col cols='12'><div class='alert' :class='msgType' role='alert'>{{msg}}</div></b-col></b-row>";
PageLayoutTemplate += "     <b-row class='sectionheader text-center'><b-col cols='12'>Project Data</b-col></b-row>";
PageLayoutTemplate += "     <b-row class='sectionbody'>";
PageLayoutTemplate += "    		<b-col md='12' lg='6'>";
PageLayoutTemplate += "     		<b-row class='sectionbody'>";
PageLayoutTemplate += "                    <b-col cols='2' class='text-center'>ERP DR #:</b-col>";
PageLayoutTemplate += "                    <b-col cols='1' class='text-center'>PPID:</b-col>";
PageLayoutTemplate += "                    <b-col cols='6' class='text-center'>Project Title</b-col>";
PageLayoutTemplate += "                    <b-col cols='3' class='text-center'>Project Manager</b-col>";
PageLayoutTemplate += "             </b-row>";
PageLayoutTemplate += "             <b-row class='sectionbody'>";
PageLayoutTemplate += "                    <b-col cols='2' class='padlr5'><b-form-input disabled v-model='projectdata.erpdr'></b-form-input></b-col>";
PageLayoutTemplate += "                    <b-col cols='1' class='padlr5'><b-form-input disabled v-model='projectdata.ppid'></b-form-input></b-col>";
PageLayoutTemplate += "                    <b-col cols='6' class='padlr5'><b-form-input disabled v-model='projectdata.title'></b-form-input></b-col>";
PageLayoutTemplate += "                    <b-col cols='3' class='padlr5'><b-form-input disabled v-model='projectdata.manager'></b-form-input></b-col>";
PageLayoutTemplate += "             </b-row>";
PageLayoutTemplate += "    	    </b-col>";
PageLayoutTemplate += "    		<b-col md='12' lg='6'>";
PageLayoutTemplate += "     		<b-row class='sectionbody'>";
PageLayoutTemplate += "                    <b-col class='text-center'>PjM Code:</b-col>";
PageLayoutTemplate += "                    <b-col class='fhidden'>CA:</b-col>";
PageLayoutTemplate += "                    <b-col class='fhidden'>ERP Resource Sponsor:</b-col>";
PageLayoutTemplate += "                    <b-col class='text-center'>Work Order ID:</b-col>";
PageLayoutTemplate += "                    <b-col class='text-center'>Customer RDD</b-col>";
PageLayoutTemplate += "                    <b-col class='text-center'>Actual Start:</b-col>";
PageLayoutTemplate += "                    <b-col class='text-center'>Planned Finish:</b-col>";
PageLayoutTemplate += "             </b-row>";
PageLayoutTemplate += "             <b-row class='sectionbody'>";
PageLayoutTemplate += "                    <b-col><b-form-input disabled v-model='projectdata.pjm'></b-form-input></b-col>";
PageLayoutTemplate += "                    <b-col class='fhidden'>{{projectdata.ca}}</b-col>";
PageLayoutTemplate += "                    <b-col class='fhidden'>{{projectdata.sponsor}}</b-col>";
PageLayoutTemplate += "                    <b-col><b-form-input disabled v-model='projectdata.workorder'></b-form-input></b-col>";
PageLayoutTemplate += "                    <b-col><b-form-input disabled v-bind:value='formatDate(projectdata.rdd)'></b-form-input></b-col>";
PageLayoutTemplate += "                    <b-col><b-form-input disabled v-bind:value='formatDate(projectdata.astart)'></b-form-input></b-col>";
PageLayoutTemplate += "                    <b-col><b-form-input disabled v-bind:value='formatDate(projectdata.pfinish)'></b-form-input></b-col>";
PageLayoutTemplate += "             </b-row>";
PageLayoutTemplate += "    	    </b-col>";
PageLayoutTemplate += "		</b-row>";

PageLayoutTemplate += "    	<b-row>";
PageLayoutTemplate += "    		<b-col md='12' lg='6'>";
PageLayoutTemplate += "                <b-row class='sectionheader text-center'><div class='col-12'>Milestone Summary</div></b-row>";
PageLayoutTemplate += "                <b-row class='sectionbody'>";
PageLayoutTemplate += "                    <div class='col-sm formlabelcenter'># Milestones</div>";
PageLayoutTemplate += "                    <div class='col-sm formlabelcenter'># Complete</div>";
PageLayoutTemplate += "                    <div class='col-sm formlabelcenter'># Completed Late</div>";
PageLayoutTemplate += "                    <div class='col-sm formlabelcenter'># On-Time</div>";
PageLayoutTemplate += "                    <div class='col-sm formlabelcenter'>% On-Time</div>";
PageLayoutTemplate += "                </b-row>";
PageLayoutTemplate += "                <b-row class='sectionbody'>";
PageLayoutTemplate += "                    <div class='col-sm formcalculated'>{{milestones.total}}</div>";
PageLayoutTemplate += "                    <div class='col-sm formcalculated'>{{milestones.complete}}</div>";
PageLayoutTemplate += "                    <div class='col-sm formcalculated'>{{milestones.completedlate}}</div>";
PageLayoutTemplate += "                    <div class='col-sm formcalculated'>{{milestones.completedontime}}</div>";
PageLayoutTemplate += "                    <div class='col-sm formcalculated'>{{milestones.percentontime}}</div>";
PageLayoutTemplate += "                </b-row>";
PageLayoutTemplate += "    	    </b-col>";
PageLayoutTemplate += "    		<b-col md='12' lg='6'>";
PageLayoutTemplate += "                <b-row class='sectionheader text-center'><div class='col-12'>Deliverable Summary</div></b-row>";
PageLayoutTemplate += "                <b-row class='sectionbody'>";
PageLayoutTemplate += "                    <div class='col-sm formlabelcenter'>Total Deliverable</div>";
PageLayoutTemplate += "                    <div class='col-sm formlabelcenter'>Quantity Delivered</div>";
PageLayoutTemplate += "                    <div class='col-sm formlabelcenter'>Quantity Delivered Late</div>";
PageLayoutTemplate += "                    <div class='col-sm formlabelcenter'>Qty Delivered On-Time</div>";
PageLayoutTemplate += "                    <div class='col-sm formlabelcenter'>% On-Time Quantity</div>";
PageLayoutTemplate += "                    <div class='col-sm formlabelcenter'>% On-Time Deliveries</div>";
PageLayoutTemplate += "                </b-row>";
PageLayoutTemplate += "                <b-row class='sectionbody'>";
PageLayoutTemplate += "                    <div class='col-sm formcalculated'>{{deliverables.total}}</div>";
PageLayoutTemplate += "                    <div class='col-sm formcalculated'>{{deliverables.quantitydelivered}}</div>";
PageLayoutTemplate += "                    <div class='col-sm formcalculated'>{{deliverables.quantitylate}}</div>";
PageLayoutTemplate += "                    <div class='col-sm formcalculated'>{{deliverables.quantityontime}}</div>";
PageLayoutTemplate += "                    <div class='col-sm formcalculated'>{{deliverables.quantityontimepercent}}</div>";
PageLayoutTemplate += "                    <div class='col-sm formcalculated'>{{deliverables.ontimedeliveries}}</div>";
PageLayoutTemplate += "                </b-row>";
PageLayoutTemplate += "    	    </b-col>";
PageLayoutTemplate += "		</b-row>";

PageLayoutTemplate += "     <b-row class='scrollable-row'>";
PageLayoutTemplate += "    		<b-col cols='12'><b-form>";
PageLayoutTemplate += "				<b-table ref='mdtable' v-model='shownData' @row-clicked='' responsive :striped='striped' :bordered='bordered' :small='small' :hover='hover' :items='items' :fields='fields'>";
PageLayoutTemplate += "					<template slot='empty'>";
PageLayoutTemplate += "						<table style='height:100%;width:100%;'>";
PageLayoutTemplate += "							<tr><td align='center'><img src='/_layouts/images/gears_an.gif' /></td></tr>";
PageLayoutTemplate += "							<tr><td align='center'><div style='margin-top: 10px; font-size: 16px;'>Getting Data...Please wait.</div></td></tr>";
PageLayoutTemplate += "						</table>";
PageLayoutTemplate += "					</template>";
//PageLayoutTemplate += "					<template slot='order' slot-scope='item'>";
//PageLayoutTemplate += "                		<b-form-select class='order' @change='reorder(\"MilestoneOrder\", shownData[item.index].ID)' v-model='shownData[item.index].order' v-bind:options='orderops' v-bind:id='getID(\"MilestoneOrder\", shownData[item.index].ID)'>";
//PageLayoutTemplate += "                			<option slot='first' v-bind:value='shownData[item.index].order'>{{shownData[item.index].order}}</option>";
//PageLayoutTemplate += "                		</b-form-select>";
//PageLayoutTemplate += "					</template>";
PageLayoutTemplate += "					<template slot='order' slot-scope='item'>";
//PageLayoutTemplate += "                		<b-form-select class='order' v-on:change='orderme(shownData[item.index].ID, item.index, numselects)' v-bind:name='getName(\"ViewOrder\", item.index)' v-model='shownData[item.index].order' v-bind:options='orderops' v-bind:id='getID(\"MilestoneOrder\", shownData[item.index].ID)'></b-form-select>";
PageLayoutTemplate += "                		<b-form-select class='order' v-on:change='orderme(item.index, numselects)' v-bind:name='getName(\"ViewOrder\", item.index)' v-model='shownData[item.index].order' v-bind:options='orderops' v-bind:id='getName(\"ViewOrder\", item.index)'></b-form-select>";
PageLayoutTemplate += "					</template>";
PageLayoutTemplate += "					<template slot='cp' slot-scope='item'>";
PageLayoutTemplate += "                		<b-form-checkbox class='' v-model='shownData[item.index].cp' value='Y' unchecked-value='N' v-bind:id='getID(\"CP\", shownData[item.index].ID)'></b-form-checkbox>";
PageLayoutTemplate += "					</template>";
PageLayoutTemplate += "					<template slot='cd' slot-scope='item'>";
PageLayoutTemplate += "                		<b-form-checkbox class='' v-model='shownData[item.index].cd' value='Y' unchecked-value='N' v-bind:id='getID(\"CD\", shownData[item.index].ID)'></b-form-checkbox>";
PageLayoutTemplate += "					</template>";
PageLayoutTemplate += "					<template slot='title' slot-scope='item'>";
PageLayoutTemplate += "                		<b-form-input @focus.native='titleFocused(item.index)' class='title' v-model='shownData[item.index].title' v-bind:id='getID(\"Title\", shownData[item.index].ID)'></b-form-input>";
PageLayoutTemplate += "					</template>";
PageLayoutTemplate += "					<template slot='delid' slot-scope='item'>";
PageLayoutTemplate += "                		<b-form-input class='delid' v-model='shownData[item.index].delid' v-bind:id='getID(\"DeliverableID\", shownData[item.index].ID)'></b-form-input>";
PageLayoutTemplate += "					</template>";
PageLayoutTemplate += "					<template slot='msps' slot-scope='item'>";
PageLayoutTemplate += "                		<el-date-picker class='' v-model='shownData[item.index].msps' type='date' @change='updateCalcs' :picker-options='dpops'></el-date-picker>";
PageLayoutTemplate += "					</template>";
PageLayoutTemplate += "					<template slot='msas' slot-scope='item'>";
PageLayoutTemplate += "                		<el-date-picker class='' v-model='shownData[item.index].msas' type='date'  @change='updateCalcs' :picker-options='dpops'></el-date-picker>";
PageLayoutTemplate += "					</template>";
PageLayoutTemplate += "					<template slot='mdplf' slot-scope='item'>";
PageLayoutTemplate += "                		<el-date-picker class='' v-model='shownData[item.index].mdplf' type='date' @change='updateCalcs' :picker-options='dpops'></el-date-picker>";
PageLayoutTemplate += "					</template>";
PageLayoutTemplate += "					<template slot='mdprf' slot-scope='item'>";
PageLayoutTemplate += "                		<el-date-picker class='' v-model='shownData[item.index].mdprf' type='date' @change='updateCalcs' :picker-options='dpops'></el-date-picker>";
PageLayoutTemplate += "					</template>";
PageLayoutTemplate += "					<template slot='mdaf' slot-scope='item'>";
PageLayoutTemplate += "                		<el-date-picker class='' v-model='shownData[item.index].mdaf' type='date' @change='changeme(\"ActualFinish\", shownData[item.index].index, shownData[item.index].ID)' :picker-options='dpops'></el-date-picker>";
PageLayoutTemplate += "					</template>";
PageLayoutTemplate += "					<template slot='pcomp' slot-scope='item'>";
PageLayoutTemplate += "                		<b-form-select class='pcomp' v-model='shownData[item.index].pcomp' v-bind:options='pcomps' v-bind:id='getID(\"PComp\", shownData[item.index].ID)'></b-form-select>";
PageLayoutTemplate += "					</template>";
PageLayoutTemplate += "					<template slot='duration' slot-scope='item'>";
PageLayoutTemplate += "                		<b-form-input class='number' v-model='shownData[item.index].duration' v-bind:id='getID(\"Duration\", shownData[item.index].ID)'></b-form-input>";
PageLayoutTemplate += "					</template>";
PageLayoutTemplate += "					<template slot='pqty' slot-scope='item'>";
PageLayoutTemplate += "                		<b-form-input class='number' v-model='shownData[item.index].pqty' v-bind:id='getID(\"PQTY\", shownData[item.index].ID)'></b-form-input>";
PageLayoutTemplate += "					</template>";
PageLayoutTemplate += "					<template slot='aqty' slot-scope='item'>";
PageLayoutTemplate += "                		<b-form-input class='number' v-model='shownData[item.index].aqty' v-bind:id='getID(\"AQTY\", shownData[item.index].ID)'></b-form-input>";
PageLayoutTemplate += "					</template>";
PageLayoutTemplate += "					<template slot='oqty' slot-scope='item'>";
PageLayoutTemplate += "                		<b-form-input class='number' v-model='shownData[item.index].oqty' v-bind:id='getID(\"OQTY\", shownData[item.index].ID)'></b-form-input>";
PageLayoutTemplate += "					</template>";
PageLayoutTemplate += "					<template slot='units' slot-scope='item'>";
PageLayoutTemplate += "                		<b-form-select class='lwc' v-model='shownData[item.index].units' v-bind:options='units' v-bind:id='getID(\"Units\", shownData[item.index].ID)'></b-form-select>";
PageLayoutTemplate += "					</template>";
PageLayoutTemplate += "					<template slot='status' slot-scope='item'>";
PageLayoutTemplate += "                		<b-form-input class='status' v-model='shownData[item.index].status' v-bind:id='getID(\"Status\", shownData[item.index].ID)'></b-form-input>";
PageLayoutTemplate += "					</template>";
PageLayoutTemplate += "					<template slot='rcc' slot-scope='item'>";
PageLayoutTemplate += "                		<b-form-select class='causecat' v-model='shownData[item.index].rcc' @change='changeme(\"RootCause\", shownData[item.index].index, shownData[item.index].ID)' v-bind:options='causecats' v-bind:id='getID(\"RootCauseCategory\", shownData[item.index].ID)'></b-form-select>";
PageLayoutTemplate += "					</template>";
PageLayoutTemplate += "					<template slot='rc' slot-scope='item'>";
PageLayoutTemplate += "                		<b-form-select class='cause' v-model='shownData[item.index].rc' v-bind:options='shownData[item.index].RootCauses' v-bind:id='getID(\"RootCause\", shownData[item.index].ID)'>";
PageLayoutTemplate += "                			<option slot='first' v-bind:value='shownData[item.index].rc'>{{shownData[item.index].rc}}</option>";
PageLayoutTemplate += "                		</b-form-select>";
PageLayoutTemplate += "					</template>";
PageLayoutTemplate += "					<template slot='pff' slot-scope='item'>";
PageLayoutTemplate += "                		<b-form-select class='phase' v-model='shownData[item.index].pff' @change='changeme(\"Phase\", shownData[item.index].index, shownData[item.index].ID)' v-bind:options='phases' v-bind:id='getID(\"Phase\", shownData[item.index].ID)'></b-form-select>";
PageLayoutTemplate += "					</template>";
PageLayoutTemplate += "					<template slot='mf' slot-scope='item'>";
PageLayoutTemplate += "                		<b-form-select class='category' data-category='shownData[item.index].mf' v-model='shownData[item.index].mf' v-bind:options='shownData[item.index].Categories' v-bind:id='getID(\"Category\", shownData[item.index].ID)'>";
PageLayoutTemplate += "                			<option slot='first' v-bind:value='shownData[item.index].mf'>{{shownData[item.index].mf}}</option>";
PageLayoutTemplate += "                		</b-form-select>";
PageLayoutTemplate += "					</template>";
PageLayoutTemplate += "					<template slot='leadwc' slot-scope='item'>";
PageLayoutTemplate += "                		<b-form-select class='lwc' v-model='shownData[item.index].leadwc' v-bind:options='branches' v-bind:id='getID(\"LeadWC\", shownData[item.index].ID)'></b-form-select>";
PageLayoutTemplate += "					</template>";
PageLayoutTemplate += "					<template slot='lead' slot-scope='item'>";
PageLayoutTemplate += "                		<div class='pplpickerdiv'><b-form-input class='lead' v-model='shownData[item.index].leadtitle' v-bind:id='getID(\"Lead\", shownData[item.index].ID)'></b-form-input>";
PageLayoutTemplate += "						<span class='pplpickerspan' @click='selectUser(item.index, shownData[item.index].ID, shownData[item.index].leadid)'><i class='fa fa-user-circle-o'></i></span></div>";
PageLayoutTemplate += "                		<b-form-input class='leadid fhidden' v-model='shownData[item.index].leadid' v-bind:id='getID(\"LeadID\", shownData[item.index].ID)'></b-form-input>";
PageLayoutTemplate += "					</template>";
PageLayoutTemplate += "					<template slot='cpwc' slot-scope='item'>";
PageLayoutTemplate += "                		<b-form-select class='cpwc' v-model='shownData[item.index].cpwc' v-bind:options='branches' v-bind:id='getID(\"CPWC\", shownData[item.index].ID)'></b-form-select>";
PageLayoutTemplate += "					</template>";
PageLayoutTemplate += "					<template slot='dl' slot-scope='item'>";
PageLayoutTemplate += "                		<b-form-input class='dl' v-model='shownData[item.index].dl' v-bind:id='getID(\"DaysLate\", shownData[item.index].ID)'></b-form-input>";
PageLayoutTemplate += "					</template>";
PageLayoutTemplate += "					<template slot='comms' slot-scope='item'>";
PageLayoutTemplate += "                		<b-form-input class='comms' v-model='shownData[item.index].comms' v-bind:id='getID(\"Comments\", shownData[item.index].ID)'></b-form-input>";
PageLayoutTemplate += "					</template>";
PageLayoutTemplate += "				</b-table>"; 
PageLayoutTemplate += "    	    </b-form></b-col>";
PageLayoutTemplate += "		</b-row>";

PageLayoutTemplate += "		<b-row>";
PageLayoutTemplate += "    		<b-col cols='12'>";
PageLayoutTemplate += "				<b-button size='sm' class='btnSave' @click='btnSaveClick' variant='success'>Save</b-button>";
PageLayoutTemplate += "				<b-button size='sm' class='btnAdd' @click='btnAddClick' variant='danger'>Add M&D</b-button>";
PageLayoutTemplate += "    	    </b-col>";
PageLayoutTemplate += "    	</b-row>";

PageLayoutTemplate += "     <b-row v-if='showMsg' class='text-center'><b-col cols='12'><div class='alert' :class='msgType' role='alert'>{{msg}}</div></b-col></b-row>";

PageLayoutTemplate += "		<b-row style='display: none;'>";
PageLayoutTemplate += "			<textarea cols='100' rows='30' id='txtData' v-model='jsonstring' style='margin-top: 20px;'></textarea>";
PageLayoutTemplate += "    </b-row>";

PageLayoutTemplate += "</b-container>";

var PageLayout = {
    template: PageLayoutTemplate,
    data: function () {
        return {
        	projectdata: { // Pulled from the project by the ERPDR passed in the querystring.
        		erpdr: IH.GLOBAL.ACTIONS.QueryString['ERPDR'], // get the ERPDR from the querystring.
        		ppid: 'empty',
        		title: 'empty',
        		manager: 'empty',
        		pjm: 'empty',
        		ca: 'empty',
        		sponsor: 'empty',
        		workorder: 'empty',
        		rdd: 'empty',
        		astart: 'empty',
        		pfinish: 'empty'
        	},
        	milestones: { // Values will be calculated
        		total: 0,
        		complete: 0,
        		completedlate: 0,
        		completedontime: 0,
        		percentontime: 0
        	},
        	deliverables: { // Values will be calculated
        		total: 0,
        		quantitydelivered: 0,
        		quantitylate: 0,
        		quantityontime: 0,
        		quantityontimepercent: 0,
        		ontimedeliveries: 0
        	},
        	peoplepicker: {
        		rowindex: 0,
        		currentId: null,
        		resolvedId: null,
        		elementId: null,
        		text: null
        	},
        	striped: true,
      		bordered: true,
      		outlined: true,
      		small: true,
      		hover: true,
      		dark: false,
      		fixed: false,
      		footClone: false,
      		fields: [
      			{ key: 'order', label: 'Order', thClass: 'text-center'},
      			{ key: 'cp', label: 'CP', thClass: 'text-center'},
      			{ key: 'cd', label: 'CD', thClass: 'text-center'},
      			{ key: 'title', label: 'Milestone Title', thClass: 'text-center'},
      			{ key: 'delid', label: 'Deliverable ID', thClass: 'text-center'},
      			{ key: 'msps', label: 'MS Planned Start', thClass: 'text-center msheader'},
      			{ key: 'msas', label: 'MS Actual Start', thClass: 'text-center msheader'},
      			{ key: 'mdplf', label: 'MD Planned Finish', thClass: 'text-center msheader'},
      			{ key: 'mdprf', label: 'MD Projected Finish', thClass: 'text-center msheader'},
      			{ key: 'mdaf', label: 'MD Actual Finish', thClass: 'text-center msheader'},
      			{ key: 'pcomp', label: '% Comp', thClass: 'text-center msheader'},
      			{ key: 'duration', label: 'Duration', thClass: 'text-center msheader'},
      			{ key: 'pqty', label: 'Planned Qty', thClass: 'text-center mdheader'},
      			{ key: 'aqty', label: 'Actual Qty', thClass: 'text-center mdheader'},
      			{ key: 'oqty', label: 'OnTime Qty', thClass: 'text-center mdheader'},
      			{ key: 'units', label: 'Units', thClass: 'text-center mdheader'},
      			{ key: 'status', label: 'Milestone Status', thClass: 'text-center'},
      			{ key: 'pff', label: 'Project Phase Filter', thClass: 'text-center'},
      			{ key: 'mf', label: 'MD Filter', thClass: 'text-center'},
      			{ key: 'leadwc', label: 'Lead WC', thClass: 'text-center'},
      			{ key: 'lead', label: 'Milestone Lead', thClass: 'text-center'},
      			{ key: 'cpwc', label: 'CP WC', thClass: 'text-center'},
      			{ key: 'dl', label: 'Days Late', thClass: 'text-center'},
      			{ key: 'comms', label: 'Comments', thClass: 'text-center'},
      			{ key: 'rcc', label: 'Root Cause Category', thClass: 'text-center'},
      			{ key: 'rc', label: 'Root Cause', thClass: 'text-center'}
      		],
      		items: [], // Will be the milestone and deilverables array for the selected project
      		shownData: [], // Will be the milestone and deilverables array used for the table
      		validation: [], // Will be equal to items on first load to see if any items have been changed or added.
        	tempdata: [], // Holds the milestones while fetching data. If there are more than the REST threshold the function loops until all are loaded.
        	phases: [], // Project Phase Filter. The phase of the milestone. Filters the category.
        	categories: [], // MD Filter. The category of the milestone. Filtered by phase.
        	orderops: [], // This will be used for ordering the milestones. It will feed the dropdowns.
        	units: [
        		{ value: 'Value', text: 'Value' },
        		{ value: 'Boxes', text: 'Boxes' },
        		{ value: 'Drums', text: 'Drums' },
        		{ value: 'Gallons', text: 'Gallons' },
        		{ value: 'Grams', text: 'Grams' },
        		{ value: 'KGrams', text: 'KGrams' },
        		{ value: 'Ounces', text: 'Ounces' },
        		{ value: 'Pallets', text: 'Pallets' },
        		{ value: 'Pounds', text: 'Pounds' },
        		{ value: 'Units', text: 'Units' },
        	],
        	pcomps: [], 
        	jsonstring: '', // Holds the md data as a string and is used to test data manipulation in the textarea
        	sh: 0,  // will hold the height of the scrolling area once all the rows are done.
        	dpops: {
        		shortcuts: [{
        			text: 'Today',
        			onClick: function (picker) {
        				picker.$emit('pick', new Date());
        			}
        		},
        		{
        			text: 'Yesterday',
        			onClick: function (picker) {
        				var date = new Date();
        				date.setTime(date.getTime() - 3600 * 1000 * 24);
        				picker.$emit('pick', date)
        			}
        		},
				{
        			text: 'A week ago',
        			onClick: function (picker) {
        				var date = new Date();
        				date.setTime(date.getTime() - 3600 * 1000 * 24 * 7);
        				picker.$emit('pick', date)
        			}
        		}]
        	},
        	causes: [],
        	causecats: [],
        	causefilter: [],
        	causeindex: 0,
        	finishchanged: false,
        	branchdata: [], // temp area for branches as the REST threshold here is only 100 items
        	branches: [],
        	dropdowns: false,
        	peoplepickers: false,
        	updated: 0,
        	numselects: 0,
        	calcvals: false,
        	showMsg: false,
            msgType: 'alert-info',
            msg: ''        
        }
    },
    created: function () {
    	for (var i = 0; i <= 100; i += 5) {
    		this.pcomps.push(i);
    	}
        this.getProjectData(null);
    },
    mounted: function () {
    	this.$nextTick(function () {
			logit("MOUNTED");
			//this.projectdata.erpdr = IH.GLOBAL.ACTIONS.QueryString['ERPDR'];
    	})
    },
    updated: function () {
    	this.updated += 1;
		var h = this.sh;  		
		h = h * 28; // 28 is the min-height of each form row
		h = h + "px";
		logit("UPDATE: " + this.updated);
		if (!this.peoplepickers) {
			var vm = this;
			var test = false;
	        jQuery(".peoplepicker").each(function (pidx) {
				if (jQuery(this).html() === '' || jQuery(this).html() === null) { 
	            	vm.initializePplPicker(jQuery(this).attr("id"));
	            	test = true;
	            }
	        });
			this.peoplepickers = test;
		}
		if (!this.dropdowns && this.sh > 0) {
			for (var i = 0; i < this.items.length; i++) {
				if (this.items[i].pff !== '') {
					var pff = this.items[i].pff;
					this.items[i]["Categories"] = this.categories.filter(function (el) {
        	 			return el.phase === pff;
        	 		});
				}
				if (this.items[i].rcc !== '') {
					var rcc = this.items[i].rcc;
					this.items[i]["RootCauses"] = this.causes.filter(function (el) {
        	 			return el.cat === rcc;
        	 		});
				}
			}
			this.dropdowns = true;
		}
		if (!this.calcvals && this.sh > 0) {
			// Time to calculate some values!
			this.updateCalcs();
			this.calcvals = true;
		}
    },
    methods: {
    	changeme: function (type, index, id) {
        	switch(type) {
        	 	case "RootCause":
        	 		var thisVal = jQuery("#RootCauseCategory_" + id + " option:selected ").val();
        	 		this.items[index]["RootCauses"] = this.causes.filter(function (el) {
        	 			return el.cat === thisVal;
        	 		});
        	 		break;
        	 	
        	 	case "Phase":
        	 		var thisVal = jQuery("#Phase_" + id + " option:selected ").val();
        	 		this.items[index]["Categories"] = this.categories.filter(function (el) {
        	 			return el.phase === thisVal;
        	 		});
        	 		break;
        	 		
        	 	case "ActualFinish":
        	 		this.causeindex = index
        	 		this.finishchanged = true;
        	 		this.updateCalcs();
        	 		break;
        	 		
        	}
        },
        causecatchanged: function () {
        	var thisVal = jQuery("#ddcausecatmodal option:selected ").val();
        	this.items[this.causeindex].rcc = thisVal;
        	jQuery("#RootCauseCategory_" + this.items[this.causeindex].ID + " option").each(function () {
                if (jQuery(this).html() === thisVal) {
                 	jQuery(this).prop('selected', true);
                }
            });
        	this.causefilter = this.causes.filter(function (el) {
        	 	return el.cat === thisVal;
        	});
        	this.items[this.causeindex].RootCauses = this.causes.filter(function (el) {
        	 	return el.cat === thisVal;
        	});
        },
        causechanged: function () {
        	var thisVal = jQuery("#ddcausemodal option:selected ").val();
        	jQuery("#RootCause_" + this.items[this.causeindex].ID + " option").each(function () {
                if (jQuery(this).html() === thisVal) {
                 	jQuery(this).prop('selected', true);
                }
            });
        	this.items[this.causeindex].rc = thisVal;
        },
    	updateCalcs : function () {
    		for (var i = 0; i < this.items.length; i++) {
				// complete
				if (this.items[i].mdaf !== '') { 
					this.milestones.complete += 1; 
					// was it late? Must have at least a planned start or actual start. This is actually calculated by dayslate.js and copied here.
					var a, dl = 0;
    				var today = moment();
    				var projfd = this.items[i].mdprf;
        			var planfd = this.items[i].mdplf;
    				var afd = this.items[i].mdaf;
        			// console.log('INFO: ' + today + ", " + pfd + ", " + afd);

					if (afd !== undefined && afd !== 'undefined' && afd !== '') { // There is an actual finish date so use it instead of today
	    				if (planfd !== undefined || planfd !== '') { // Use these dates to determine how late it was
	    					a = moment(afd);
            				a.add(a.utcOffset() * -1, 'm');
            				b = moment(planfd);
            				dl = a.diff(b, 'days');
            			}
            			else { 
            				if (projfd !== undefined && projfd !== '') { // Use these dates to determine how late it was
	    						a = moment(afd);
            					a.add(a.utcOffset() * -1, 'm');
            					b = moment(planfd);
            					dl = a.diff(b, 'days');
            				}
            				else { // Can't calculate if there is no projected or planned finish date
            					dl= -9999;
            				}
            			}
	    			}
	    			else {
	    				if (planfd !== undefined && planfd !== '') { // There is a planned finish date so use it first
	    					a = moment(planfd);
            				a.add(a.utcOffset() * -1, 'm');
            				dl = today.diff(a, 'days');
	    				}
	    				else { 	    		
	    					if (projfd !== undefined && projfd !== '') { // Use these dates to determine how late it was
	    						a = moment(projfd);
            					a.add(a.utcOffset() * -1, 'm');
            					dl = today.diff(a, 'days');
            				}
            				else { // Can't calculate if there is no projected or planned finish date
            					dl= -9999;
            				}
	    				}
	    			}
	    			
	    			switch (true) {
	    				case dl === -9999:
	        				this.items[i].dl = "NA";
	        				jQuery("#Title_" + this.items[i].ID).parent().parent().removeClass('table-rootcause'); // just in case it was applied
	        				break;

	    				case dl < 0:
	        				this.items[i].dl = dl;
	        				this.milestones.completedontime += 1;
	        				jQuery("#Title_" + this.items[i].ID).parent().parent().removeClass('table-rootcause'); // just in case it was applied
	        				// format for not late
	        				break;
	
	    				case dl == 0:
	        				this.items[i].dl = dl;
	        				this.milestones.completedontime += 1;
	        				jQuery("#Title_" + this.items[i].ID).parent().parent().removeClass('table-rootcause'); // just in case it was applied
            				// formate for done today?
	        				break;
	
	    				case dl > 0:
	        				this.items[i].dl = dl;
	        				this.milestones.completedlate += 1;
	        				jQuery("#DaysLate_" + this.items[i].ID).addClass('islate');
            				// format for late and prompt for root cause
            				if (this.items[i].rcc === null || this.items[i].rc === null) { 
            					jQuery("#Title_" + this.items[i].ID).parent().parent().addClass('table-rootcause');
            					if (this.finishchanged) {
            						this.finishchanged = false;
            						this.$refs['causemodal'].show();
								}  
            				}
            				else {
            					jQuery("#Title_" + this.items[i].ID).parent().parent().removeClass('table-rootcause');
            				}
	        				break;
					}
				}
				
				// on time percent
				if (this.milestones.complete > 0 && this.milestones.completedontime > 0) { 
					this.milestones.percentontime = (this.milestones.completedontime / this.milestones.complete) * 100;
				}
				
			}
    	},
    	causeselected: function () {
    		this.updateCalcs();
    		this.$refs['causemodal'].hide();
    	},
        getProjectData: function () {
            var zurl = site + "/_api/lists/getbytitle('ProjectExecutionMain')/items?";
            zurl += "$select=Id,Title,ProjectTitle,PPID/Title,PM/Title,PjMCode/Title,PjMCode/Branch,CA/Title,ERPResourceSponsor/Title,WorkOrderID,CustomerRDD,ActualStart,PlannedFinish";
            zurl += "&$expand=PPID,PM,PjMCode,CA,ERPResourceSponsor";
            zurl += "&$filter=(Title eq '" + this.projectdata.erpdr + "')";
            
            console.log("Project URL: " + zurl);
            var vm = this;
            jQuery.ajax({
                url: zurl,
                method: "GET",
                headers: { 'accept': 'application/json; odata=verbose' },
                error: function (jqXHR, textStatus, errorThrown) {
                    logit("Error Status: " + textStatus + ":: errorThrown: " + errorThrown);
                },
                success: function (data) {
                	var j = data.d.results[0];
                	var stop = 'stop';
            		vm.projectdata.ppid = j['PPID']['Title'];
	        		vm.projectdata.title = j['ProjectTitle'];
	        		vm.projectdata.manager = j['PM']['Title'];
	        		vm.projectdata.pjm = j['PjMCode']['Branch'];
	        		vm.projectdata.ca = j['CA']['Title'];
	        		vm.projectdata.sponsor = j['ERPResourceSponsor']['Title'];
	        		vm.projectdata.workorder = j['WorkOrderID'];
	        		vm.projectdata.rdd = j['CustomerRDD'];
	        		vm.projectdata.astart = j['ActualStart'];
	        		vm.projectdata.pfinish = j['PlannedFinish'];
	        		vm.getCausesAndCats(); // Get the root cause categories
                } 
            });
        },
        getCausesAndCats: function () {
        	var curl = site + "/_api/lists/getbytitle('RootCauses')/items?";
	        curl += "$select=ID,Title,Category";
	        curl += "&$orderby=Category";
			
			var vm = this;
            jQuery.ajax({
                url: curl,
                method: "GET",
                headers: { 'accept': 'application/json; odata=verbose' },
                error: function (jqXHR, textStatus, errorThrown) {
                    logit("Error Status: " + textStatus + ":: errorThrown: " + errorThrown);
                },
                success: function (data) {
                	var j = jQuery.parseJSON(JSON.stringify(data.d.results));
                	for (var k = 0; k < j.length; k++) {
                		if (vm.causecats.indexOf(j[k]["Category"]) < 0) {
                			vm.causecats.push(j[k]["Category"]);
                		}
                		vm.causes.push({
                			"value": j[k]["Title"],
                			"text": j[k]["Title"],
                			"cat": j[k]["Category"]
                		});
                	}
                	// vm.getMAD(null);
                	vm.getPhasesAndCats();
                }
            });
        },
        getPhasesAndCats: function () {
        	var curl = site + "/_api/lists/getbytitle('PhasesandCategories')/items?";
	        curl += "$select=ID,Title,Phase";
	        curl += "&$orderby=Phase";
			
			var vm = this;
            jQuery.ajax({
                url: curl,
                method: "GET",
                headers: { 'accept': 'application/json; odata=verbose' },
                error: function (jqXHR, textStatus, errorThrown) {
                    logit("Error Status: " + textStatus + ":: errorThrown: " + errorThrown);
                },
                success: function (data) {
                	var stop = "stop";
                	var j = jQuery.parseJSON(JSON.stringify(data.d.results));
                	for (var k = 0; k < j.length; k++) {
                		if (vm.phases.indexOf(j[k]["Phase"]) < 0) {
                			vm.phases.push(j[k]["Phase"]);
                		}
                		vm.categories.push({
                			"value": j[k]["Title"],
                			"text": j[k]["Title"],
                			"phase": j[k]["Phase"]
                		});
                	}
                	//vm.getMAD(null);
                	vm.getBranches(null);
                }
            });
        },
        getBranches: function (curl) {
        	if (curl === null) {
	        	curl = site + "/_api/lists/getbytitle('Org Table')/items?";
		        curl += "$select=ID,Title,Branch";
		        curl += "&$orderby=Branch";
			}
			
			var vm = this;
            jQuery.ajax({
                url: curl,
                method: "GET",
                headers: { 'accept': 'application/json; odata=verbose' },
                error: function (jqXHR, textStatus, errorThrown) {
                    logit("Error Status: " + textStatus + ":: errorThrown: " + errorThrown);
                },
                success: function (data) {
                	vm.branchdata = vm.branchdata.concat(data.d.results);
                	if (data.d.__next) {
                		curl = data.d.__next;
                		vm.getBranches(curl);
                	}
					else {
	                	var stop = "stop";
	                	var j = jQuery.parseJSON(JSON.stringify(vm.branchdata));
	                	for (var k = 0; k < j.length; k++) {
	                		vm.branches.push({
	                			"value": j[k]["Branch"],
	                			"text": j[k]["Branch"]
	                		});
	                	}
	                	vm.getMAD(null);
                	}
                }
            });
        },
        getMAD: function (murl) {
        	if (murl === null) {
	        	murl = site + "/_api/lists/getbytitle('MilestonesAndDeliverables')/items?";
	        	murl += "$select=*,MileStoneLead/Title,MileStoneLead/ID,MileStoneLead/Name";
	        	murl += "&$orderby=MilestoneOrder&$expand=MileStoneLead";
	            murl += "&$filter=(ERPID eq '" + this.projectdata.erpdr + "')";
	        }

        	var vm = this;
            jQuery.ajax({
                url: murl,
                method: "GET",
                headers: { 'accept': 'application/json; odata=verbose' },
                error: function (jqXHR, textStatus, errorThrown) {
                    logit("Error Status: " + textStatus + ":: errorThrown: " + errorThrown);
                },
                success: function (data) {
                	vm.tempdata = vm.tempdata.concat(data.d.results);
                	if (data.d.__next) {
                		murl = data.d.__next;
                		vm.getMAD(murl);
                	}
                	else {
                		// var stop = 'stop';
                		vm.tempdata = jQuery.parseJSON(JSON.stringify(vm.tempdata));
                		var stop = 'stop';
                		for (var i = 0; i < vm.tempdata.length; i++) {
                			// build orderops
                			vm.orderops.push(i + 1);
                			
                			vm.milestones.total += 1;
                			
                			vm.items.push({
                				_rowVariant: '',
                				index: i,
                				ID: vm.tempdata[i]["ID"],
                				RootCauses: [],
                				Categories: [],
                				order: i + 1,  //vm.tempdata[i]["MilestoneOrder"],
                				cp: vm.tempdata[i]["CriticalPath"],
                				cd: vm.tempdata[i]["CustomerDeliverable"],
                				title: vm.tempdata[i]["Title"],
      							delid: vm.tempdata[i]["DeliverableID"],
      							msps: vm.tempdata[i]["PlannedStart"],
      							msas: vm.tempdata[i]["ActualStart"],
      							mdplf: vm.tempdata[i]["PlannedFinish"],
      							mdprf: vm.tempdata[i]["ProjectedFinish"],
      							mdaf: vm.tempdata[i]["ActualFinish"],      							
      							duration: vm.tempdata[i]["Duration"],
      							pcomp: vm.tempdata[i]["PercentComplete"],
      							pqty: vm.tempdata[i]["PlannedQuantity"],
      							aqty: vm.tempdata[i]["ActualQuantity"],
      							oqty: vm.tempdata[i]["OnTimeQuantity"],
      							units: vm.tempdata[i]["Units"],
      							status: vm.tempdata[i]["Status"],
      							rcc: vm.tempdata[i]["RootCauseCategory"],
      							rc: vm.tempdata[i]["RootCause"],      							
      							pff: vm.tempdata[i]["Phase"],
      							mf: vm.tempdata[i]["Category"],
      							leadwc: vm.tempdata[i]["LeadWC"],
      							lead: vm.tempdata[i]["MileStoneLead"]['Name'],
      							leadid: vm.tempdata[i]["MileStoneLead"]['ID'],
      							leadtitle: vm.tempdata[i]["MileStoneLead"]['Title'],
      							cpwc: vm.tempdata[i]["CPWC"],
      							dl: 0,
      							comms: vm.tempdata[i]["Comments"]
                			});
                			
                			vm.validation.push({
                				_rowVariant: '',
                				index: i,
                				ID: vm.tempdata[i]["ID"],
                				RootCauses: [],
                				Categories: [],
                				order: vm.tempdata[i]["MilestoneOrder"],
                				cp: vm.tempdata[i]["CriticalPath"],
                				cd: vm.tempdata[i]["CustomerDeliverable"],
                				title: vm.tempdata[i]["Title"],
      							delid: vm.tempdata[i]["DeliverableID"],
      							msps: vm.tempdata[i]["PlannedStart"],
      							msas: vm.tempdata[i]["ActualStart"],
      							mdplf: vm.tempdata[i]["PlannedFinish"],
      							mdprf: vm.tempdata[i]["ProjectedFinish"],
      							mdaf: vm.tempdata[i]["ActualFinish"],      							
      							duration: vm.tempdata[i]["Duration"],
      							pcomp: vm.tempdata[i]["PercentComplete"],
      							pqty: vm.tempdata[i]["PlannedQuantity"],
      							aqty: vm.tempdata[i]["ActualQuantity"],
      							oqty: vm.tempdata[i]["OnTimeQuantity"],
      							units: vm.tempdata[i]["Units"],
      							status: vm.tempdata[i]["Status"],
      							rcc: vm.tempdata[i]["RootCauseCategory"],
      							rc: vm.tempdata[i]["RootCause"],      							
      							pff: vm.tempdata[i]["Phase"],
      							mf: vm.tempdata[i]["Category"],
      							leadwc: vm.tempdata[i]["LeadWC"],
      							lead: vm.tempdata[i]["MileStoneLead"]['Name'],
      							leadid: vm.tempdata[i]["MileStoneLead"]['ID'],
      							leadtitle: vm.tempdata[i]["MileStoneLead"]['Title'],
      							cpwc: vm.tempdata[i]["CPWC"],
      							dl: 0,
      							comms: vm.tempdata[i]["Comments"]
                			});
                		}
                		//vm.validation = vm.items;
                		vm.sh = vm.items.length;
                		vm.numselects = vm.items.length;
                	}
                }
            });
        },
        getID: function (text, id) {
        	return text + "_" + id;
        },
        getName: function (text, idx) {
        	return text + idx;
        },
        titleFocused: function(index) {
        	logit("FOCUSED: " + index);
        	for (var i = 0; i < this.items.length; i++ ) {
        		if (i == index) {
        			logit("Set Variant");
        			//this.items[i]._rowVariant="active";
        			jQuery("#Title_" + this.items[i].ID).parent().parent().addClass('table-active');
        		}
        		else {
        			//this.items[i]._rowVariant="";
        			jQuery("#Title_" + this.items[i].ID).parent().parent().removeClass('table-active');
        		}
        	}
        },
        btnAddClick: function () {
        	// need to add new item to the table. There are several ways to add items but we are going to see about adding an item to the items array first.
        	// we also need to increase the orderops array to ensure we get the count straight.
        	// we also need to ensure that the peoplepicker gets set for this row.
        	// TODO: Validate a need to save any data first. Currently this may not need to be done.
        	this.orderops.push(this.orderops.length + 1);
        	
        	this.items.push({
                _rowVariant: '',
                index: this.items.length,
                ID: 'NEW',
				RootCauses: [],
                Categories: [],
                order: this.items.length + 1,
                cp: 'N',
                cd: 'N',
                title: 'New Item',
      			delid: '',
      			msps: '',
      			msas: '',
      			mdplf: '',
      			mdprf: '',
      			mdaf: '',      							
      			duration: '',
      			pcomp: '0',
      			pqty: '0',
      			aqty: '0',
      			oqty: '0',
      			units: '',
      			status: '',
      			rcc: '',
      			rc: '',      							
      			pff: '',
      			mf: '',
      			leadwc: '',
      			lead: '',
      			leadtitle: '',
      			cpwc: '',
      			dl: '',
      			comms: ''
            });
            this.sh += 1;
        },
        btnSaveClick: function () {
        	this.msg = "";
        	this.showMsg = false;
        	this.msg = "Checking Data. Please Wait...";
        	this.msgType = "alert-info";
        	this.showMsg = true;
        	this.jsonstring = JSON.stringify(this.validation) + "\r\n" + JSON.stringify(this.items);
        	if (JSON.stringify(this.items) === JSON.stringify(this.validation)) {
        		// Nothing to save so just go back or go home
        		// TODO validate where this needs to go since it is a new window/tab
        		logit("Data not changed.");
        		this.msgType = "alert-success";
        		this.msg = "Data unchanged. Redirecting...";
        	}
			else {
				// May need to have some validation but just loop and save...
				var vm = this;
				vm.msg = "Saving Data. Please Wait...";
        		vm.msgType = "alert-warning";
        		IH.GLOBAL.VARIABLES.total = this.items.length;
        		IH.GLOBAL.VARIABLES.redirect = window.location; // TODO validate this is correct location
        		// get a form digest so we can update data.
        		IH.GLOBAL.ACTIONS.getFormDigest(site).then(function (data) {
        			IH.GLOBAL.VARIABLES.digest = data.d.GetContextWebInformation.FormDigestValue;
        			// build out options to pass to saving call
					for (var i = 0; i < vm.items.length; i++) {
						var itemprops = {
							"__metadata": { "type": "SP.Data.MilestonesAndDeliverablesListItem"},
							"ERPID": vm.projectdata.erpdr,
							"MilestoneOrder": vm.items[i].order, // actually need to get this from the dropdown
                			"CriticalPath": vm.items[i].cp,
                			"CustomerDeliverable": vm.items[i].cd,
                			"Title": vm.items[i].title,
      						"DeliverableID": vm.items[i].delid,  
      						"PlannedStart": vm.items[i].msps,
      						"ActualStart": vm.items[i].msas,
      						"PlannedFinish": vm.items[i].mdplf,
      						"ProjectedFinish": vm.items[i].mdprf,
      						"ActualFinish": vm.items[i].mdaf,     							
      						"Duration": Number(vm.items[i].duration),
      						"PercentComplete": Number(vm.items[i].pcomp),
      						"PlannedQuantity": Number(vm.items[i].pqty),
      						"ActualQuantity": Number(vm.items[i].aqty),
      						"OnTimeQuantity": Number(vm.items[i].oqty),
      						"Units": vm.items[i].units,
      						"Status": vm.items[i].status,
      						"RootCauseCategory": vm.items[i].rcc,
      						"RootCause": vm.items[i].rc,      						
      						"Phase": vm.items[i].pff,
      						"Category": vm.items[i].mf,
      						"LeadWC": vm.items[i].leadwc,
      						"MileStoneLeadId": Number(vm.items[i].leadid),
      						"CPWC": vm.items[i].cpwc,
							"Comments": vm.items[i].comms
						};      				
      					var itemdata = {};
      					itemdata.ID = vm.items[i].ID;
      					
      					// TODO check for new item and call addItem instead.
      					// TODO validate if this item by itself changed or not. This may be the case if only 1 or 2 items are either new or changed
      					if(!moment(itemprops["PlannedStart"]).isValid()) { itemprops["PlannedStart"] = null} else { itemprops["PlannedStart"] = moment(itemprops["PlannedStart"]).add(8, "hours").format('YYYY-MM-DD[T]HH:MM:[00Z]') };
      					if(!moment(itemprops["ActualStart"]).isValid()) { itemprops["ActualStart"] = null} else { itemprops["ActualStart"] = moment(itemprops["ActualStart"]).add(8, "hours").format('YYYY-MM-DD[T]HH:MM:[00Z]') };
      					if(!moment(itemprops["PlannedFinish"]).isValid()) { itemprops["PlannedFinish"] = null} else { itemprops["PlannedFinish"] = moment(itemprops["PlannedFinish"]).add(8, "hours").format('YYYY-MM-DD[T]HH:MM:[00Z]') };
      					if(!moment(itemprops["ProjectedFinish"]).isValid()) { itemprops["ProjectedFinish"] = null} else { itemprops["ProjectedFinish"] = moment(itemprops["ProjectedFinish"]).add(8, "hours").format('YYYY-MM-DD[T]HH:MM:[00Z]') };
      					if(!moment(itemprops["ActualFinish"]).isValid()) { itemprops["ActualFinish"] = null} else { itemprops["ActualFinish"] = moment(itemprops["ActualFinish"]).add(8, "hours").format('YYYY-MM-DD[T]HH:MM:[00Z]') };
      					itemdata.itemprops = itemprops;
      					if (itemdata.ID === 'NEW') {
      						IH.GLOBAL.ACTIONS.addNewItem(site, "MilestonesAndDeliverables", itemprops).success(IH.GLOBAL.ACTIONS.addNewItemSuccess);
      					}
      					else {
      						IH.GLOBAL.ACTIONS.getItemById(site, "MilestonesAndDeliverables", itemdata.ID).success(IH.GLOBAL.ACTIONS.getItemByIdSuccess.bind(itemdata));
      					}
					}
        		});
				
				vm.msgType = "alert-success";
        		vm.msg = "Data saved. Redirecting...";
			}
        },
        formatDate: function (d) {
            return d === null ? "" : moment(d).format("MM/DD/YYYY");
        },
        getAge: function (d) {
            var a = moment();
            var b = moment(d);
            var age = a.diff(b, 'days');// + " days";
            return age;
        },
        orderme: function(index, numSelects) {
        	var select = document.getElementById("ViewOrder" + index);
        	var obj = IH.GLOBAL.ACTIONS.reorder(select, index, numSelects);
        	for (var i = 0; i < this.items.length; i++) {
        		var a = Number(jQuery("#ViewOrder" + i).val());
        		this.items[i].order = a;
        		logit(i + ", " + a);
			}       	
        	var stop = "stop";
        },
        selectUser: function (index, id, lead) {
        	logit(index + ", " + id + ", " + lead);
        	this.peoplepicker.rowindex = index;
        	this.peoplepicker.currentId = lead;
        	this.$refs['pickermodal'].show();
        },
        userselected: function () {
        	// The people picker should be resolved at this point 
        	var stop = "stop";
        	var a = String(jQuery("#pickermodal").find("input[id*='TopSpan_HiddenInput']").val());
        	if (a.indexOf("EntityData") > 0) {
        		var b = JSON.parse(a);
                this.items[this.peoplepicker.rowindex].leadid = b[0].EntityData.SPUserID;
                this.items[this.peoplepicker.rowindex].leadtitle = b[0].DisplayText;
                this.$refs['pickermodal'].hide();
        	}
        	else {
        		// TODO: Test if this ever happens
        		logit("USER NOT RESOLVED!");
        	}
        },
        initializePplPicker: function (peoplePickerElementId) {
        	// Create a schema to store picker properties, and set the properties.
	        var schema = {};
	        schema['PrincipalAccountType'] = 'User,SPGroup'; // 'User,DL,SecGroup,SPGroup'
	        schema['SearchPrincipalSource'] = 1;  // 15; 1 = just the userinfolist, 15 = all sources
	        schema['ResolvePrincipalSource'] = 1;  // 15; 1 = just users, 15 = all types
	        schema['AllowMultipleValues'] = false;
	        schema['MaximumEntitySuggestions'] = 10;
	        schema['Width'] = '250px';
	        // Render and initialize the picker. 
	        // Pass the ID of the DOM element that contains the picker, an array of initial
	        // PickerEntity objects to set the picker value, and a schema that defines
	        // picker properties.
	        SPClientPeoplePicker_InitStandaloneControlWrapper(peoplePickerElementId, null, schema);
        }
    },
    components: {
        // 'recommendations-table': RecommendationsTable,
        // 'recommendations-by-status': RecommendationsByStatus,
        // 'recommendations-by-org': RecommendationsByOrg,
        // 'recommendations-implemented-by-org': ImplementedByOrg,
        // 'recommendations-summary': RecSummaryTable
    }
}
