﻿var IH = IH || {};
IH.CSOM = IH.CSOM || {};
IH.REST = IH.REST || {};
IH.GLOBAL = IH.GLOBAL || {};
IH.GLOBAL.ACTIONS = IH.GLOBAL.ACTIONS || {};

IH.GLOBAL.VARIABLES = {
    SLASH: "/",
    site: null,
    redirect: null,
    digest: null,
    response: [],
    waitdlg: null, // potential use of different notification mechanism
    status: null, // potential use of different notification mechanism
    controlnumber: null,  // Used for passing a control number in your functions.
    sitecollection: null,
    data: null,
    json: null,
    total: 0,
    count: 0,
    batchstart: 0,
    batchend: 0,
    currentuser: { // used to staore data for logged in user
        id: null,
        login: null,
        org: null,
        type: null
    }
}

function logit(msg) { // global console logging function
    if (typeof console != "undefined") {
        console.log(msg + " AT: " + new Date());
    }
}

function EncodeHTML(str) {
    return String(str).replace(/"/g, '&quot;').replace(/&/g, '&amp;').replace(/'/g, '&#39;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}

function DecodeHTML(str) {
    return String(str).replace(/&amp;/g, '&').replace(/&#39;/g, "'").replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"');
}

function loadCSS(url) {
    var head = document.getElementsByTagName('head')[0];
    var style = document.createElement('link');
    style.type = 'text/css';
    style.rel = 'stylesheet';
    style.href = url;
    head.appendChild(style);
}

function loadstyle(url, callback) {
    var head = document.getElementsByTagName('head')[0];
    var style = document.createElement('link');    
    style.type = 'text/css';
    style.rel = 'stylesheet';
    if (style.readyState) {  //IE
        style.onreadystatechange = function () {
            if (style.readyState == "loaded" ||
                    style.readyState == "complete") {
                style.onreadystatechange = null;
                callback();
            }
        };
    } else {  //Others
        style.onload = function () {
            callback();
        };
    }
    style.href = url;
    head.appendChild(style);
}


function loadscript(url, callback) {
    var script = document.createElement("script")
    script.type = "text/javascript";
    if (script.readyState) {  //IE
        script.onreadystatechange = function () {
            if (script.readyState == "loaded" ||
                    script.readyState == "complete") {
                script.onreadystatechange = null;
                callback();
            }
        };
    } else {  //Others
        script.onload = function () {
            callback();
        };
    }
    script.src = url;
    document.documentElement.insertBefore(script, document.documentElement.firstChild);
}


// jQuery plugin to read data passed in a querystring
(function (JQ) {
    JQ.QueryString = (function (a) {
        if (a == "") return {};
        var b = {};
        for (var i = 0; i < a.length; ++i) {
            var p = a[i].split('=');
            if (p.length != 2) continue;
            b[p[0]] = decodeURIComponent(p[1].replace(/\+/g, " "));
        }
        return b;
    })(window.location.search.substr(1).split('&'))
})(jQuery);

IH.GLOBAL.ACTIONS.QueryString = (function (a) {
	if (a == "") return {};
    var b = {};
    for (var i = 0; i < a.length; ++i) {
        var p = a[i].split('=');
        if (p.length != 2) continue;
        b[p[0]] = decodeURIComponent(p[1].replace(/\+/g, " "));
    }
    return b;
})(window.location.search.substr(1).split('&'))

IH.GLOBAL.ACTIONS.reorder = function (eSelect, iCurrentField, numSelects) {
	var eForm = eSelect.form;
    var iNewOrder = eSelect.selectedIndex + 1;
    var iPrevOrder;
    var positions = new Array(numSelects);
    var ix;
    var ret = {
    	si: null,
    	pos: null
    };
    for (ix = 0; ix < numSelects; ix++) {
        positions[ix] = 0;
    }
    for (ix = 0; ix < numSelects; ix++) {
        positions[eSelect.form["ViewOrder" + ix].selectedIndex] = 1;
    }
    for (ix = 0; ix < numSelects; ix++) {
        if (positions[ix] == 0) {
            iPrevOrder = ix + 1;
            break;
        }
    }
    if (iNewOrder != iPrevOrder) {
        var iInc = iNewOrder > iPrevOrder ? -1 : 1
        var iMin = Math.min(iNewOrder, iPrevOrder);
        var iMax = Math.max(iNewOrder, iPrevOrder);
        for (var iField = 0; iField < numSelects; iField++) {
            if (iField != iCurrentField) {
                if (eSelect.form["ViewOrder" + iField].selectedIndex + 1 >= iMin && eSelect.form["ViewOrder" + iField].selectedIndex + 1 <= iMax) {
                    eSelect.form["ViewOrder" + iField].selectedIndex += iInc;
                    ret.si = eSelect.form["ViewOrder" + iField].selectedIndex;
                }
            }
            else {
            	ret.si = eSelect.form["ViewOrder" + iCurrentField].selectedIndex;
            }
            //logit("iField: " + iField + ", seletedIndex: " + ret);
        }
    }
    ret.pos = positions;
    return ret;
}

IH.GLOBAL.ACTIONS.getFormDigest = function (url) {
	return jQuery.ajax({
		url: url + "/_api/contextinfo",
		method: "POST",
		headers: { "Accept": "application/json; odata=verbose" }
	});
}

IH.GLOBAL.ACTIONS.getItemById = function (webUrl, listName, itemId) {
    var url = webUrl + "/_api/lists/getbytitle('" + listName + "')/items(" + itemId + ")";

    return jQuery.ajax({
        url: url,
        method: "GET",
        headers: { "Accept": "application/json; odata=verbose" }
    });
}

IH.GLOBAL.ACTIONS.getItemByIdSuccess = function (data) {
    var itemdata = this;
    IH.GLOBAL.ACTIONS.updateItem(itemdata.itemprops, data.d.__metadata.uri, data.d.__metadata.etag).success(IH.GLOBAL.ACTIONS.updateItemSuccess.bind(itemdata)).fail(IH.GLOBAL.ACTIONS.updateItemFail.bind(itemdata));
}

IH.GLOBAL.ACTIONS.updateItem = function(itemProperties, url, tag) {
    return jQuery.ajax({
        type: 'POST',
        url: url,
        contentType: 'application/json',
        processData: false,
        headers: {
        	"Content-Type": "application/json;odata=verbose",
            "Accept": "application/json;odata=verbose",
            "X-HTTP-Method": "MERGE",
            "If-Match": tag,
            "X-RequestDigest": IH.GLOBAL.VARIABLES.digest
        },
        data: JSON.stringify(itemProperties)
    });
}

IH.GLOBAL.ACTIONS.updateItemSuccess = function (data) {
    var v = IH.GLOBAL.VARIABLES;
    v.count += 1;
    $("#txtData").append("\r\n" + "Item v.count=" + v.count + ", ID=" + this.ID + " -- Updated ");
    if (v.count === v.batchend && this.action === "updateData") {
        IH.ADMIN.ACTIONS().updateData(v.count);
    }
    if (v.count === v.total) {
        window.location = v.redirect;
    }
}

IH.GLOBAL.ACTIONS.updateItemFail = function (data) {
    var v = IH.GLOBAL.VARIABLES;
    v.count += 1;
    $("#txtData").append("\r\n" + "Item v.count=" + v.count + ", ID=" + this.ID + " -- Failed ");
    if (v.count === v.batchend && this.action === "updateData") {
        IH.ADMIN.ACTIONS().updateData(v.count);
    }
    if (v.count === v.total) {
        window.location = v.redirect;
    }
}


IH.GLOBAL.ACTIONS.addNewItem = function(site, listName, itemProperties) {
	var url = site + "/_api/lists/getbytitle('" + listName + "')/items";
    return jQuery.ajax({
        type: 'POST',
        url: url,
        contentType: 'application/json',
        processData: false,
        headers: {
        	"Content-Type": "application/json;odata=verbose",
            "Accept": "application/json;odata=verbose",
            "X-HTTP-Method": "POST",
            "X-RequestDigest": IH.GLOBAL.VARIABLES.digest
        },
        data: JSON.stringify(itemProperties)
    });
}

IH.GLOBAL.ACTIONS.addNewItemSuccess = function (data) {
    var v = IH.GLOBAL.VARIABLES;
    v.count += 1;
    $("#txtData").append("\r\n" + "Item v.count=" + v.count + " -- Added ");
    if (v.count === v.batchend && this.action === "updateData") {
        IH.ADMIN.ACTIONS().updateData(v.count);
    }
    if (v.count === v.total) {
        window.location = v.redirect;
    }
}

IH.GLOBAL.ACTIONS.addNewItemFail = function (data) {
    var v = IH.GLOBAL.VARIABLES;
    v.count += 1;
    $("#txtData").append("\r\n" + "Item v.count=" + v.count + " ERPID:" + this.itemprops.ERPID + " Title: " + this.itemprops.Title + " -- Failed ");
    if (v.count === v.batchend && this.action === "updateData") {
        IH.ADMIN.ACTIONS().updateData(v.count);
    }
    if (v.count === v.total) {
        window.location = v.redirect;
    }
}

