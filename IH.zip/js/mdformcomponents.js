﻿var SLASH = "/";
var tp1 = new String(window.location.protocol);
var tp2 = new String(window.location.host);
var site = tp1 + SLASH + SLASH + tp2 + _spPageContextInfo.webServerRelativeUrl;

ELEMENT.locale(ELEMENT.lang.en);

var PageLayoutTemplate = "";
PageLayoutTemplate += "<b-modal id='mainmodal' ref='mainmodal' no-close-on-esc no-close-on-backdrop centered size='lg' :title='msg' cancel-variant='danger' ok-variant='success'>";
PageLayoutTemplate += "<b-container fluid class='pageform'>";
PageLayoutTemplate += "    <b-row>";
PageLayoutTemplate += "    		<b-col cols='6'>";
PageLayoutTemplate += "            <b-container fluid class='section'>";
PageLayoutTemplate += "                <b-row class='sectionheader text-center'><div class='col-12'>Milestone Summary</div></b-row>";
PageLayoutTemplate += "                <b-row class='sectionbody'>";
PageLayoutTemplate += "                    <div class='col-sm formlabelcenter'># Milestones</div>";
PageLayoutTemplate += "                    <div class='col-sm formlabelcenter'># Complete</div>";
PageLayoutTemplate += "                    <div class='col-sm formlabelcenter'># Completed Late</div>";
PageLayoutTemplate += "                    <div class='col-sm formlabelcenter'># On-Time</div>";
PageLayoutTemplate += "                    <div class='col-sm formlabelcenter'>% On-Time</div>";
PageLayoutTemplate += "                </b-row>";
PageLayoutTemplate += "    	        </b-container>";
PageLayoutTemplate += "    	    </b-col>";
PageLayoutTemplate += "    		<b-col cols='6'>";
PageLayoutTemplate += "            <b-container fluid class='section'>";
PageLayoutTemplate += "                <b-row class='sectionheader text-center'><div class='col-12'>Deliverable Summary</div></b-row>";
PageLayoutTemplate += "                <b-row class='sectionbody'>";
PageLayoutTemplate += "                    <div class='col-sm formlabelcenter'>Total Deliverable</div>";
PageLayoutTemplate += "                    <div class='col-sm formlabelcenter'>Quantity Delivered</div>";
PageLayoutTemplate += "                    <div class='col-sm formlabelcenter'>Quantity Delivered Late</div>";
PageLayoutTemplate += "                    <div class='col-sm formlabelcenter'>Qty Delivered On-Time</div>";
PageLayoutTemplate += "                    <div class='col-sm formlabelcenter'>% On-Time Quantity</div>";
PageLayoutTemplate += "                    <div class='col-sm formlabelcenter'>% On-Time Deliveries</div>";
PageLayoutTemplate += "                </b-row>";
PageLayoutTemplate += "    	        </b-container>";
PageLayoutTemplate += "    	    </b-col>";
PageLayoutTemplate += "		</b-row>";
PageLayoutTemplate += "    	<b-row>";
PageLayoutTemplate += "    		<b-col cols='6'>";
PageLayoutTemplate += "            <b-container fluid class='section'>";
PageLayoutTemplate += "                <b-row class='sectionbody'>";
PageLayoutTemplate += "                    <div class='col-sm formcalculated'>{{milestones.total}}</div>";
PageLayoutTemplate += "                    <div class='col-sm formcalculated'>{{milestones.complete}}</div>";
PageLayoutTemplate += "                    <div class='col-sm formcalculated'>{{milestones.completedlate}}</div>";
PageLayoutTemplate += "                    <div class='col-sm formcalculated'>{{milestones.completedontime}}</div>";
PageLayoutTemplate += "                    <div class='col-sm formcalculated'>{{milestones.percentontime}}</div>";
PageLayoutTemplate += "                </b-row>";
PageLayoutTemplate += "    	        </b-container>";
PageLayoutTemplate += "    	    </b-col>";
PageLayoutTemplate += "    		<b-col cols='6'>";
PageLayoutTemplate += "            <b-container fluid class='section'>";
PageLayoutTemplate += "                <b-row class='sectionbody'>";
PageLayoutTemplate += "                    <div class='col-sm formcalculated'>{{deliverables.total}}</div>";
PageLayoutTemplate += "                    <div class='col-sm formcalculated'>{{deliverables.quantitydelivered}}</div>";
PageLayoutTemplate += "                    <div class='col-sm formcalculated'>{{deliverables.quantitylate}}</div>";
PageLayoutTemplate += "                    <div class='col-sm formcalculated'>{{deliverables.quantityontime}}</div>";
PageLayoutTemplate += "                    <div class='col-sm formcalculated'>{{deliverables.quantityontimepercent}}</div>";
PageLayoutTemplate += "                    <div class='col-sm formcalculated'>{{deliverables.ontimedeliveries}}</div>";
PageLayoutTemplate += "                </b-row>";
PageLayoutTemplate += "    	        </b-container>";
PageLayoutTemplate += "    	    </b-col>";
PageLayoutTemplate += "		</b-row>";
PageLayoutTemplate += "    	<b-row>";
PageLayoutTemplate += "    		<b-col cols='12'>";
PageLayoutTemplate += "            <b-container fluid class='section'>";
PageLayoutTemplate += "                <b-row class='sectionbody'>";
PageLayoutTemplate += "                    <div class='erpdr formlabelleft'>ERP DR #:</div>";
PageLayoutTemplate += "                    <div class='ppid formlabelleft'>PPID:</div>";
PageLayoutTemplate += "                    <div class='ptitle formlabelleft'>Project Title</div>";
PageLayoutTemplate += "                    <div class='pm formlabelleft'>Project Manager</div>";
PageLayoutTemplate += "                    <div class='pmcode formlabelleft'>PjM Code:</div>";
PageLayoutTemplate += "                    <div class='ca formlabelleft'>CA:</div>";
PageLayoutTemplate += "                    <div class='sponsor formlabelleft'>ERP Resource Sponsor:</div>";
PageLayoutTemplate += "                </b-row>";
PageLayoutTemplate += "    	        </b-container>";
PageLayoutTemplate += "    	    </b-col>";
PageLayoutTemplate += "		</b-row>";
PageLayoutTemplate += "    	<b-row>";
PageLayoutTemplate += "    		<b-col cols='12'>";
PageLayoutTemplate += "            <b-container fluid class='section'>";
PageLayoutTemplate += "                <b-row class='sectionbody'>";
PageLayoutTemplate += "                    <div class='erpdr formtext'>{{projectdata.erpdr}}</div>";
PageLayoutTemplate += "                    <div class='ppid formtext'>{{projectdata.ppid}}</div>";
PageLayoutTemplate += "                    <div class='ptitle formtext'>{{projectdata.title}}</div>";
PageLayoutTemplate += "                    <div class='pm formtext'>{{projectdata.manager}}</div>";
PageLayoutTemplate += "                    <div class='pmcode formtext'>{{projectdata.pjm}}</div>";
PageLayoutTemplate += "                    <div class='ca formtext'>{{projectdata.ca}}</div>";
PageLayoutTemplate += "                    <div class='sponsor formtext'>{{projectdata.sponsor}}</div>";
PageLayoutTemplate += "                </b-row>";
PageLayoutTemplate += "    	        </b-container>";
PageLayoutTemplate += "    	    </b-col>";
PageLayoutTemplate += "		</b-row>";
PageLayoutTemplate += "    	<b-row>";
PageLayoutTemplate += "    		<b-col cols='12'>";
PageLayoutTemplate += "            <b-container fluid class='section'>";
PageLayoutTemplate += "                <b-row class='sectionbody'>";
PageLayoutTemplate += "                    <div class='formlabel100'>Work Order ID:</div>";
PageLayoutTemplate += "                    <div class='formlabel100'>Customer RDD</div>";
PageLayoutTemplate += "                    <div class='formlabel100'>Actual Start:</div>";
PageLayoutTemplate += "                    <div class='formlabel100'>Planned Finish:</div>";
PageLayoutTemplate += "                </b-row>";
PageLayoutTemplate += "    	        </b-container>";
PageLayoutTemplate += "    	    </b-col>";
PageLayoutTemplate += "		</b-row>";
PageLayoutTemplate += "    	<b-row>";
PageLayoutTemplate += "    		<b-col cols='12'>";
PageLayoutTemplate += "            <b-container fluid class='section'>";
PageLayoutTemplate += "                <b-row class='sectionbody'>";
PageLayoutTemplate += "                    <div class='formtext100'>{{projectdata.workorder}}</div>";
PageLayoutTemplate += "                    <div class='formtext100'>{{formatDate(projectdata.rdd)}}</div>";
PageLayoutTemplate += "                    <div class='formtext100'>{{formatDate(projectdata.astart)}}</div>";
PageLayoutTemplate += "                    <div class='formtext100'>{{formatDate(projectdata.pfinish)}}</div>";
PageLayoutTemplate += "                </b-row>";
PageLayoutTemplate += "    	        </b-container>";
PageLayoutTemplate += "    	    </b-col>";
PageLayoutTemplate += "		</b-row>";
PageLayoutTemplate += "</b-container>";

//  SETTING UP PANE FREEZING SO THAT PART OF THE UI CAN SCROLL 

PageLayoutTemplate += "<div class='scroll-pane-container' id='scroll-pane-container'>";
PageLayoutTemplate += "     <b-row no-gutters class='scrolling-row'>";
PageLayoutTemplate += "			<div class='left-pane-fixed'>";
PageLayoutTemplate += "     		<b-row no-gutters class='left-pane-header'>";
PageLayoutTemplate += "                		<b-form inline class='mfheaderform'>";
PageLayoutTemplate += "         				<div class='custom-form-label text-center'><div class='order'>Order</div></div>";
PageLayoutTemplate += "         				<div class='custom-form-label text-center'><div class='cp'>CP</div></div>";
PageLayoutTemplate += "         				<div class='custom-form-label text-center'><div class='cd'>CD</div></div>";
PageLayoutTemplate += "         				<div class='custom-form-label text-center'><div class='title-label'>Milestone Title</div></div>";
PageLayoutTemplate += "         				<div class='custom-form-label text-center'><div class='delid-label'>Deliverable ID</div></div>";
PageLayoutTemplate += "         				<div class='custom-form-label text-center'><div class='dp'>MS Planned<br/>Start</div></div>";
PageLayoutTemplate += "         				<div class='custom-form-label text-center'><div class='dp'>MS Actual<br/>Start</div></div>";
PageLayoutTemplate += "                			<div class='custom-form-label text-center'><div class='dp'>MD Planned<br/>Finish</div></div>";
PageLayoutTemplate += "                			<div class='custom-form-label text-center'><div class='dp'>MD Projected<br/>Finish</div></div>";
PageLayoutTemplate += "                			<div class='custom-form-label text-center'><div class='dp'>MD Actual<br/>Finish</div></div>";
PageLayoutTemplate += "                		</b-form inline>";
PageLayoutTemplate += "				</b-row>";
PageLayoutTemplate += "     		<b-row no-gutters class='left-pane-form' id='left-pane-form'>";
PageLayoutTemplate += "     			<b-form-row no-gutters v-for='m in md' class='mfbrow'>";
PageLayoutTemplate += "                		<b-form inline changed='false' v-bind:index='m.index' v-bind:id='m.ID'>";
PageLayoutTemplate += "                			<b-form-select class='mb-2 mr-sm-2' @change='reorder(\"MilestoneOrder\", m.ID)' v-model='m.MilestoneOrder' v-bind:options='orderops' v-bind:id='getID(\"MilestoneOrder\", m.ID)'>";
PageLayoutTemplate += "                				<option slot='first' v-bind:value='m.MilestoneOrder'>{{m.MilestoneOrder}}</option>";
PageLayoutTemplate += "                			</b-form-select>";
PageLayoutTemplate += "                			<b-form-checkbox class='mb-2 mr-sm-2' v-model='m.CP' value='Y' unchecked-value='N' v-bind:id='getID(\"CP\", m.ID)'></b-form-checkbox>";
PageLayoutTemplate += "                			<b-form-checkbox class='mb-2 mr-sm-2' v-model='m.CD' value='Y' unchecked-value='N' v-bind:id='getID(\"CD\", m.ID)'></b-form-checkbox>";
PageLayoutTemplate += "                			<b-form-input class='mb-2 mr-sm-2 title-input' v-model='m.Title' v-bind:id='getID(\"Title\", m.ID)'></b-form-input>";
PageLayoutTemplate += "                			<b-form-input class='mb-2 mr-sm-2 delid-input' v-model='m.DeliverableID' v-bind:id='getID(\"DeliverableID\", m.ID)'></b-form-input>";
PageLayoutTemplate += "                			<el-date-picker class='mb-2 mr-sm-2' v-model='m.PlannedStart' type='date' :picker-options='dpops'></el-date-picker>";
PageLayoutTemplate += "                			<el-date-picker class='mb-2 mr-sm-2' v-model='m.ActualStart' type='date' :picker-options='dpops'></el-date-picker>";
PageLayoutTemplate += "                			<el-date-picker class='mb-2 mr-sm-2' v-model='m.PlannedFinish' type='date' :picker-options='dpops'></el-date-picker>";
PageLayoutTemplate += "                			<el-date-picker class='mb-2 mr-sm-2' v-model='m.ProjectedFinish' type='date' :picker-options='dpops'></el-date-picker>";
PageLayoutTemplate += "                			<el-date-picker class='mb-2 mr-sm-2' v-model='m.ActualFinish' type='date' :picker-options='dpops'></el-date-picker>";
PageLayoutTemplate += "                		</b-form>";
PageLayoutTemplate += "     			</b-form-row>";
PageLayoutTemplate += "				</b-row>";
PageLayoutTemplate += "			</div>";
PageLayoutTemplate += "			<div class='right-pane-scroll'>";
PageLayoutTemplate += "     		<b-row no-gutters class='right-pane-header'>";
PageLayoutTemplate += "                		<b-form inline class='mfheaderform'>";
PageLayoutTemplate += "                			<div class='custom-form-label text-center'><div class='number-label'>Duration</div></div>";
PageLayoutTemplate += "                			<div class='custom-form-label text-center'><div class='number-label'>Percent<br/>Complete</div></div>";
PageLayoutTemplate += "                			<div class='custom-form-label text-center'><div class='number-label'>Planned<br/>Qty</div></div>";
PageLayoutTemplate += "                			<div class='custom-form-label text-center'><div class='number-label'>Actual<br/>Qty</div></div>";
PageLayoutTemplate += "                			<div class='custom-form-label text-center'><div class='number-label'>OnTime<br/>Qty</div></div>";
PageLayoutTemplate += "                			<div class='custom-form-label text-center'><div class='number-label'>Units</div></div>";
PageLayoutTemplate += "                			<div class='custom-form-label text-center'><div class='status-label'>Milestone Status</div></div>";
PageLayoutTemplate += "                			<div class='custom-form-label text-center'><div class='causecat-label'>Root Cause Category</div></div>";
PageLayoutTemplate += "                			<div class='custom-form-label text-center'><div class='cause-label'>Root Cause</div></div>";
PageLayoutTemplate += "                			<div class='custom-form-label text-center'><div class='phase-label'>Project Phase Filter</div></div>";
PageLayoutTemplate += "                			<div class='custom-form-label text-center'><div class='category-label'>MD Filter</div></div>";
PageLayoutTemplate += "                			<div class='custom-form-label text-center'><div class='lwc-label'>Lead WC</div></div>";
PageLayoutTemplate += "                			<div class='custom-form-label text-center'><div class='lead-label'>Milestone Lead</div></div>";
PageLayoutTemplate += "                			<div class='custom-form-label text-center'><div class='cpwc-label'>CP WC</div></div>";
PageLayoutTemplate += "                			<div class='custom-form-label text-center'><div class='dl-label'>Days Late</div></div>";
PageLayoutTemplate += "                			<div class='custom-form-label text-center'><div class='com-label'>Comments</div></div>";
PageLayoutTemplate += "                		</b-form inline>";
PageLayoutTemplate += "     		</b-row>";
PageLayoutTemplate += "     		<b-row no-gutters class='right-pane-form' id='right-pane-form'>";
PageLayoutTemplate += "     			<b-form-row no-gutters v-for='m in md' class='mfbrow'>";
PageLayoutTemplate += "                		<b-form inline changed='false' v-bind:index='m.index' v-bind:id='m.ID'>";
PageLayoutTemplate += "                			<b-form-input class='mb-2 mr-sm-2 number-input' v-model='m.Duration' v-bind:id='getID(\"Duration\", m.ID)'></b-form-input>";
PageLayoutTemplate += "                			<b-form-input class='mb-2 mr-sm-2 number-input' v-model='m.PercentComplete' v-bind:id='getID(\"PercentComplete\", m.ID)'></b-form-input>";
PageLayoutTemplate += "                			<b-form-input class='mb-2 mr-sm-2 number-input' v-model='m.PlannedQuantity' v-bind:id='getID(\"PlannedQuantity\", m.ID)'></b-form-input>";
PageLayoutTemplate += "                			<b-form-input class='mb-2 mr-sm-2 number-input' v-model='m.ActualQuantity' v-bind:id='getID(\"ActualQuantity\", m.ID)'></b-form-input>";
PageLayoutTemplate += "                			<b-form-input class='mb-2 mr-sm-2 number-input' v-model='m.OnTimeQuantity' v-bind:id='getID(\"OnTimeQuantity\", m.ID)'></b-form-input>";
PageLayoutTemplate += "                			<b-form-input class='mb-2 mr-sm-2 number-input' v-model='m.Units' v-bind:id='getID(\"Units\", m.ID)'></b-form-input>";
PageLayoutTemplate += "                			<b-form-input class='mb-2 mr-sm-2 status-input' v-model='m.Status' v-bind:id='getID(\"Status\", m.ID)'></b-form-input>";
PageLayoutTemplate += "                			<b-form-select class='mb-2 mr-sm-2 causecat-select' v-model='m.RootCauseCategory' @change='changeme(\"RootCause\", m.index, m.ID)' v-bind:options='causecats' v-bind:id='getID(\"RootCauseCategory\", m.ID)'></b-form-select>";
PageLayoutTemplate += "                			<b-form-select class='mb-2 mr-sm-2 cause-select' v-model='m.RootCause' v-bind:options='m.RootCauses' v-bind:id='getID(\"RootCause\", m.ID)'></b-form-select>";
PageLayoutTemplate += "                			<b-form-select class='mb-2 mr-sm-2 phase-select' v-model='m.Phase' @change='changeme(\"Phase\", m.index, m.ID)' v-bind:options='phases' v-bind:id='getID(\"Phase\", m.ID)'></b-form-select>";
PageLayoutTemplate += "                			<b-form-select class='mb-2 mr-sm-2 category-select' v-model='m.Category' v-bind:options='m.Categories' v-bind:id='getID(\"Category\", m.ID)'></b-form-select>";
PageLayoutTemplate += "                			<b-form-select class='mb-2 mr-sm-2 lwc-select' v-model='m.LeadWC' v-bind:options='branches' v-bind:id='getID(\"LeadWC\", m.ID)'></b-form-select>";
PageLayoutTemplate += "                			<div class='mb-2 mr-sm-2 msl-input peoplepicker' v-model='m.MilestoneLead' v-bind:id='getID(\"MilestoneLead\", m.ID)'></div>";
PageLayoutTemplate += "                			<b-form-select class='mb-2 mr-sm-2 cpwc-select' v-model='m.CPWC' v-bind:options='branches' v-bind:id='getID(\"CPWC\", m.ID)'></b-form-select>";
PageLayoutTemplate += "                			<b-form-input class='mb-2 mr-sm-2 late-input' v-model='m.DaysLate' v-bind:id='getID(\"DaysLate\", m.ID)'></b-form-input>";
PageLayoutTemplate += "                			<b-form-input class='mb-2 mr-sm-2 comms-input' v-model='m.Comments' v-bind:id='getID(\"Comments\", m.ID)'></b-form-input>";
PageLayoutTemplate += "                		</b-form>";
PageLayoutTemplate += "     			</b-form-row>";
PageLayoutTemplate += "				</b-row>";
PageLayoutTemplate += "			</div>";
PageLayoutTemplate += "     </b-row>";
PageLayoutTemplate += "</div>";

// Setup the sliders for controlling the scroll

PageLayoutTemplate += "<div class='right-scroll-container'>";
PageLayoutTemplate += "		<input type='range' class='right-scroll-slider' min='1' max='100' step='1' value='100' data-rangeslider data-orientation='vertical'></input>";
PageLayoutTemplate += "</div>";

PageLayoutTemplate += "<div class='bottom-scroll-container'>";
PageLayoutTemplate += "		<input type='range' class='bottom-scroll-slider' min='0' value='0' data-rangeslider></input>";
PageLayoutTemplate += "</div>";

// Add textarea for testing will not be visible when live but can be shown

PageLayoutTemplate += "<b-container fluid class='pageform'>";
PageLayoutTemplate += "<textarea cols='100' rows='30' id='txtData' v-model='jsonstring' style='margin-top: 20px;'></textarea>";
PageLayoutTemplate += "</b-container>";

PageLayoutTemplate += "</b-modal>";


var PageLayout = {
    template: PageLayoutTemplate,
    data: function () {
        return {
        	projectdata: { // Pulled from the project by the ERPDR passed in the querystring.
        		erpdr: $.QueryString['ERPDR'], // get the ERPDR from the querystring.
        		ppid: 'empty',
        		title: 'empty',
        		manager: 'empty',
        		pjm: 'empty',
        		ca: 'empty',
        		sponsor: 'empty',
        		workorder: 'empty',
        		rdd: 'empty',
        		astart: 'empty',
        		pfinish: 'empty'
        	},
        	milestones: { // Values will be calculated
        		total: 10,
        		complete: 8,
        		completedlate: 2,
        		completedontime: 6,
        		percentontime: 60
        	},
        	deliverables: { // Values will be calculated
        		total: 100,
        		quantitydelivered: 50,
        		quantitylate: 50,
        		quantityontime: 50,
        		quantityontimepercent: 50,
        		ontimedeliveries: 10
        	},
        	tempdata: [], // Holds the milestones while fetching data. If there are more than the REST threshold the function loops until all are loaded.
        	phases: [], // Project Phase Filter. The phase of the milestone. Filters the category.
        	categories: [], // MD Filter. The category of the milestone. Filtered by phase.
        	orderops: [], // This will be used for ordering the milestones. It will feed the dropdowns.
        	md: [], // Will be the milestone and deilverables array for the selected project
        	jsonstring: '', // Holds the md data as a string and is used to test data manipulation in the textarea
        	sh: 0,  // will hold the height of the scrolling area once all the rows are done.
        	dpops: {
        		shortcuts: [{
        			text: 'Today',
        			onClick: function (picker) {
        				picker.$emit('pick', new Date());
        			}
        		},
        		{
        			text: 'Yesterday',
        			onClick: function (picker) {
        				var date = new Date();
        				date.setTime(date.getTime() - 3600 * 1000 * 24);
        				picker.$emit('pick', date)
        			}
        		},
				{
        			text: 'A week ago',
        			onClick: function (picker) {
        				var date = new Date();
        				date.setTime(date.getTime() - 3600 * 1000 * 24 * 7);
        				picker.$emit('pick', date)
        			}
        		}]
        	},
        	causes: [],
        	causecats: [],
        	branchdata: [], // temp area for branches as the REST threshold here is only 100 items
        	branches: [],
        	sliders: false,
        	peoplepickers: false,
            msg: 'Milestones And Deliverables'        
        }
    },
    created: function () {
        this.getProjectData(null);
    },
    mounted: function () {
    	this.$nextTick(function () {

    	})
    },
    updated: function () {
    	this.jsonstring = JSON.stringify(this.md);
		var h = this.sh;  		
		h = h * 28; // 28 is the min-height of each form row
		h = h + "px";
		logit("HEIGHT: " + h);
		if (!this.sliders) {
			jQuery(".right-scroll-slider").rangeslider({
				polyfill: false,
    			rangeClass: 'right__rangeslider',
    			disabledClass: 'rangeslider--disabled',
    			horizontalClass: 'rangeslider--horizontal',
    			verticalClass: 'rangeslider--vertical',
    			fillClass: 'right__rangeslider__fill',
    			handleClass: 'rangeslider__handle',
    			
    			onSlide: function(position, value) {
    				// use the slider value to scroll the 2 form panes up and down
    				value = 100 - value >= 1 ? 100 - value : 0;
    				value = value === 0 ? 0 : value * 28;
    				logit("p: " + position + ", v: " + value);
    				document.getElementById("left-pane-form").scrollTop = value;
    				document.getElementById("right-pane-form").scrollTop = value;
    			}
    		});
    		
    		jQuery(".bottom-scroll-slider").rangeslider({
    			polyfill: false,
    			rangeClass: 'rangeslider',
    			disabledClass: 'rangeslider--disabled',
    			horizontalClass: 'rangeslider--horizontal',
    			verticalClass: 'rangeslider--vertical',
    			fillClass: 'rangeslider__fill',
    			handleClass: 'rangeslider__handle',
    			
    			onSlide: function(position, value) {
    				// use the slider value to scroll the right pane under the left one
    				value = value >= 1 ? value * 50 : 0;
    				logit("p: " + position + ", v: " + value);
    				document.getElementById("scroll-pane-container").scrollLeft = value;
    			}
    		});
    		this.sliders = true;
		}
		if (!this.peoplepickers) {
			var vm = this;
			var test = false;
			jQuery(".peoplepicker").each(function (pidx) {
				if (jQuery(this).html() === '' || jQuery(this).html() === null) { 
	            	vm.initializePeoplePicker(jQuery(this).attr("id"));
	            	test = true;
	            }
	        });
			this.peoplepickers = test;
		}
    },
    methods: {
        getProjectData: function () {
            var zurl = site + "/_api/lists/getbytitle('ProjectExecutionMain')/items?";
            zurl += "$select=Id,Title,ProjectTitle,PPID/Title,PM/Title,PjMCode/Title,PjMCode/Branch,CA/Title,ERPResourceSponsor/Title,WorkOrderID,CustomerRDD,ActualStart,PlannedFinish";
            zurl += "&$expand=PPID,PM,PjMCode,CA,ERPResourceSponsor";
            zurl += "&$filter=(Title eq '" + this.projectdata.erpdr + "')";
            
            console.log("Project URL: " + zurl);
            var vm = this;
            jQuery.ajax({
                url: zurl,
                method: "GET",
                headers: { 'accept': 'application/json; odata=verbose' },
                error: function (jqXHR, textStatus, errorThrown) {
                    logit("Error Status: " + textStatus + ":: errorThrown: " + errorThrown);
                },
                success: function (data) {
                	var j = data.d.results[0];
                	var stop = 'stop';
            		vm.projectdata.ppid = j['PPID']['Title'];
	        		vm.projectdata.title = j['ProjectTitle'];
	        		vm.projectdata.manager = j['PM']['Title'];
	        		vm.projectdata.pjm = j['PjMCode']['Branch'];
	        		vm.projectdata.ca = j['CA']['Title'];
	        		vm.projectdata.sponsor = j['ERPResourceSponsor']['Title'];
	        		vm.projectdata.workorder = j['WorkOrderID'];
	        		vm.projectdata.rdd = j['CustomerRDD'];
	        		vm.projectdata.astart = j['ActualStart'];
	        		vm.projectdata.pfinish = j['PlannedFinish'];
	        		vm.$refs['mainmodal'].show(); // showing modal before loading all mds
	        		vm.getCausesAndCats(); // Get the root cause categories
                } 
            });
        },
        getCausesAndCats: function () {
        	var curl = site + "/_api/lists/getbytitle('RootCauses')/items?";
	        curl += "$select=ID,Title,Category";
	        curl += "&$orderby=Category";
			
			var vm = this;
            jQuery.ajax({
                url: curl,
                method: "GET",
                headers: { 'accept': 'application/json; odata=verbose' },
                error: function (jqXHR, textStatus, errorThrown) {
                    logit("Error Status: " + textStatus + ":: errorThrown: " + errorThrown);
                },
                success: function (data) {
                	var j = jQuery.parseJSON(JSON.stringify(data.d.results));
                	for (var k = 0; k < j.length; k++) {
                		if (vm.causecats.indexOf(j[k]["Category"]) < 0) {
                			vm.causecats.push(j[k]["Category"]);
                		}
                		vm.causes.push({
                			"value": j[k]["Title"],
                			"text": j[k]["Title"],
                			"cat": j[k]["Category"]
                		});
                	}
                	// vm.getMAD(null);
                	vm.getPhasesAndCats();
                }
            });
        },
        getPhasesAndCats: function () {
        	var curl = site + "/_api/lists/getbytitle('PhasesandCategories')/items?";
	        curl += "$select=ID,Title,Phase";
	        curl += "&$orderby=Phase";
			
			var vm = this;
            jQuery.ajax({
                url: curl,
                method: "GET",
                headers: { 'accept': 'application/json; odata=verbose' },
                error: function (jqXHR, textStatus, errorThrown) {
                    logit("Error Status: " + textStatus + ":: errorThrown: " + errorThrown);
                },
                success: function (data) {
                	var stop = "stop";
                	var j = jQuery.parseJSON(JSON.stringify(data.d.results));
                	for (var k = 0; k < j.length; k++) {
                		if (vm.phases.indexOf(j[k]["Phase"]) < 0) {
                			vm.phases.push(j[k]["Phase"]);
                		}
                		vm.categories.push({
                			"value": j[k]["Title"],
                			"text": j[k]["Title"],
                			"phase": j[k]["Phase"]
                		});
                	}
                	//vm.getMAD(null);
                	vm.getBranches(null);
                }
            });
        },
        getBranches: function (curl) {
        	if (curl === null) {
	        	curl = site + "/_api/lists/getbytitle('Org Table')/items?";
		        curl += "$select=ID,Title,Branch";
		        curl += "&$orderby=Branch";
			}
			
			var vm = this;
            jQuery.ajax({
                url: curl,
                method: "GET",
                headers: { 'accept': 'application/json; odata=verbose' },
                error: function (jqXHR, textStatus, errorThrown) {
                    logit("Error Status: " + textStatus + ":: errorThrown: " + errorThrown);
                },
                success: function (data) {
                	vm.branchdata = vm.branchdata.concat(data.d.results);
                	if (data.d.__next) {
                		curl = data.d.__next;
                		vm.getBranches(curl);
                	}
					else {
	                	var stop = "stop";
	                	var j = jQuery.parseJSON(JSON.stringify(vm.branchdata));
	                	for (var k = 0; k < j.length; k++) {
	                		vm.branches.push({
	                			"value": j[k]["Branch"],
	                			"text": j[k]["Branch"]
	                		});
	                	}
	                	vm.getMAD(null);
                	}
                }
            });
        },
        getMAD: function (murl) {
        	if (murl === null) {
	        	murl = site + "/_api/lists/getbytitle('MilestonesAndDeliverables')/items?";
	        	murl += "$select=*";
	        	murl += "&$orderby=MilestoneOrder";
	            murl += "&$filter=(ERPID eq '" + this.projectdata.erpdr + "')";
	        }

        	var vm = this;
            jQuery.ajax({
                url: murl,
                method: "GET",
                headers: { 'accept': 'application/json; odata=verbose' },
                error: function (jqXHR, textStatus, errorThrown) {
                    logit("Error Status: " + textStatus + ":: errorThrown: " + errorThrown);
                },
                success: function (data) {
                	vm.tempdata = vm.tempdata.concat(data.d.results);
                	if (data.d.__next) {
                		murl = data.d.__next;
                		vm.getMAD(murl);
                	}
                	else {
                		// var stop = 'stop';
                		vm.tempdata = jQuery.parseJSON(JSON.stringify(vm.tempdata));
                		var stop = 'stop';
                		for (var i = 0; i < vm.tempdata.length; i++) {
                			// build orderops
                			vm.orderops.push(i + 1);
                			
                			// need to manually build md from tempdata to add indexing for original data before changes are made
                			vm.md.push({
                				"index": i,
                				"ID": vm.tempdata[i]["ID"],
                				"MilestoneOrder": vm.tempdata[i]["MilestoneOrder"],
                				"CP": vm.tempdata[i]["CriticalPath"],
                				"CD": vm.tempdata[i]["CustomerDeliverable"],
                				"Title": vm.tempdata[i]["Title"],
                				"PlannedStart": vm.tempdata[i]["PlannedStart"],
                				"ActualStart": vm.tempdata[i]["ActualStart"],
                				"PlannedFinish": vm.tempdata[i]["PlannedFinish"],
                				"ProjectedFinish": vm.tempdata[i]["ProjectedFinish"],
                				"ActualFinish": vm.tempdata[i]["ActualFinish"],
                				"Duration": vm.tempdata[i]["Duration"],
                				"PercentComplete": vm.tempdata[i]["PercentComplete"],
                				"PlannedQuantity": vm.tempdata[i]["PlannedQuantity"],
                				"ActualQuantity": vm.tempdata[i]["ActualQuantity"],
                				"OnTimeQuantity": vm.tempdata[i]["OnTimeQuantity"],
                				"Units": vm.tempdata[i]["Units"],
                				"Status": vm.tempdata[i]["Status"],
								"RootCauses": [],
								"RootCauseCategory": vm.tempdata[i]["RootCauseCategory"],
								"RootCause": vm.tempdata[i]["RootCause"],
								"Categories": [],
								"Phase": vm.tempdata[i]["Phase"],
								"Category": vm.tempdata[i]["Category"],
                				"LeadWC": vm.tempdata[i]["LeadWC"],
                				"MilestoneLead": vm.tempdata[i]["MilestoneLead"],
                				"CPWC": vm.tempdata[i]["CPWC"],
                				"DaysLate": vm.tempdata[i]["DaysLate"],
                				"Comments": vm.tempdata[i]["Comments"]
                			});
                			vm.sh += 1;
                		}
                		stop = 'stop';
                	}
                }
            });
        },
        getID: function (text, id) {
        	return text + "_" + id;
        },
        formatDate: function (d) {
            return d === null ? "" : moment(d).format("MM/DD/YYYY");
        },
        getAge: function (d) {
            var a = moment();
            var b = moment(d);
            var age = a.diff(b, 'days');// + " days";
            return age;
        },
        reorder: function (type, id) {
        	alert("Value selected: " + jQuery("#" + type + "_" + id + " option:selected ").val());
        },
        filterarr: function (cat) {
        
        },
        changeme: function (type, index, id) {
        	switch(type) {
        	 	case "RootCause":
        	 		var thisVal = jQuery("#RootCauseCategory_" + id + " option:selected ").val();
        	 		this.md[index]["RootCauses"] = this.causes.filter(function (el) {
        	 			return el.cat === thisVal;
        	 		});
        	 		break;
        	 	
        	 	case "Phase":
        	 		var thisVal = jQuery("#Phase_" + id + " option:selected ").val();
        	 		this.md[index]["Categories"] = this.categories.filter(function (el) {
        	 			return el.phase === thisVal;
        	 		});
        	 		break;

        	}
        },
        initializePeoplePicker: function (peoplePickerElementId) {
        	// Create a schema to store picker properties, and set the properties.
	        var schema = {};
	        schema['PrincipalAccountType'] = 'User,SPGroup'; // 'User,DL,SecGroup,SPGroup'
	        schema['SearchPrincipalSource'] = 1;  // 15; 1 = just the userinfolist, 15 = all sources
	        schema['ResolvePrincipalSource'] = 1;  // 15; 1 = just users, 15 = all types
	        schema['AllowMultipleValues'] = false;
	        schema['MaximumEntitySuggestions'] = 10;
	        schema['Width'] = '250px';
	        // Render and initialize the picker. 
	        // Pass the ID of the DOM element that contains the picker, an array of initial
	        // PickerEntity objects to set the picker value, and a schema that defines
	        // picker properties.
	        SPClientPeoplePicker_InitStandaloneControlWrapper(peoplePickerElementId, null, schema);
	        // The pickers modify the dom so we need to add attributes to the newly created items
	        jQuery("#" + peoplePickerElementId).find("input[id*='TopSpan_HiddenInput']").each(function () {
	            //jQuery(this).attr("onchange", "NNS.PCR.EditForm().changeme(this)");
	            //jQuery(this).attr("data-function", "Request");
	            //jQuery(this).attr("data-modified", "false");
	            //jQuery(this).attr("data-observe", "true");
	            //jQuery(this).attr("data-lastval", "");
	            //jQuery(this).addClass("PCRData");
	            //jQuery(this).addClass("hiddenpplpicker");
	            //jQuery(this).parent().addClass("form-control");
	        });
        },
        editRec: function (id) {
            zurl = fixurl('/Lists/Recommendations/EditForm.aspx?ID=' + id + '&IsDlg=1');
            CKODialog(zurl, 'Edit Recommendation', '1100', '800', 'NotificationCallback');
        }
    },
    components: {
        // 'recommendations-table': RecommendationsTable,
        // 'recommendations-by-status': RecommendationsByStatus,
        // 'recommendations-by-org': RecommendationsByOrg,
        // 'recommendations-implemented-by-org': ImplementedByOrg,
        // 'recommendations-summary': RecSummaryTable
    }
}
