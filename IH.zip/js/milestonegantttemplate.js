﻿var MilestoneGanttTemplate = "<div>";
MilestoneGanttTemplate += "<div class='ganttmessage' v-if='loading'><b-spinner small variant='danger' />{{loadingmsg}}</div>";
//MilestoneGanttTemplate += "<div class='ganttbuttons'>";
MilestoneGanttTemplate += "	<b-button class='smallbutton' @click.stop='ganttYear'>Years</b-button>"; 
MilestoneGanttTemplate += "	<b-button class='smallbutton' @click='ganttMonth'>Months</b-button>";
MilestoneGanttTemplate += "	<b-button class='smallbutton' @click='ganttDay'>Days</b-button>";
//MilestoneGanttTemplate += "</div>";
//MilestoneGanttTemplate += "<div :ref='\"ganttdiv_\" + erpid' :id='\"ganttdiv_\" + erpid' class='msgantt'></div>";
//MilestoneGanttTemplate += "<div id='gantt_here' class='msgantt'></div>";
MilestoneGanttTemplate += "<div v-bind:ref='\"ganttdiv_\" + erpid' v-bind:id='getID(\"ganttdiv\", erpid)' class='msgantt'></div>";
MilestoneGanttTemplate += "</div>";


var MilestoneGantt = {
	template: MilestoneGanttTemplate,
	data: function () {
		return {
      		totalrows: 0, 		
      		mstd: [],  // tempdata while querying milestones. Used to recursively load milestones.
      		gantt: null,
			ganttdrawn: false,
    		script: null,
    		tasks: {
    			data: [],
    			links: []
    		},
			loading: false,
			loadingmsg: 'Getting Data'
      	}
    },
    props: [
    	'erpid',
    	'project'
    ],
    mounted: function () {
    	this.$nextTick(function () {
			var vm = this;
			this.$root.$on('ganttshown', function (eid) {
				logit("Passed ID: " + eid);
				if(!vm.loading) {
					if (vm.erpid === eid) {
						vm.gantt = gantt;
						vm.mstd.length = 0;
						vm.loading = true;
						vm.getMAD(null);
					}
				}
			});
    	});
    },
    created: function () {
    	//this.getMAD(null);
    },
    updated: function () {
    	logit("GANTT UPDATED");
    },
    methods: {
    	getID: function (text, id) {
        	return text + "_" + id;
        },
        ganttYear: function () {
			this.loading = true;
			this.setScale('year');
			this.gantt.render();
			this.loading = false;
		},
		ganttMonth: function () {
			this.setScale('month');
			this.gantt.render();
		},
		ganttDay: function () {
			this.setScale('day');
			this.gantt.render();
		},
		setScale: function (size) {
			// TODO: size will be calculated later based on longest miletsone duration
			switch (size) {
				case 'year':
					this.gantt.config.scale_unit = "year";
		            this.gantt.config.date_scale = "%Y";
		            //this.gantt.templates.date_scale = null;
		            this.gantt.config.scale_height = 25;
		            this.gantt.config.row_height = 25;
		            this.gantt.config.subscales = [
		                { unit: "month", step: 1, date: "%M" }
		            ];
					break;
					
				case 'month':
					this.gantt.config.scale_unit = "month";
		            this.gantt.config.date_scale = "%M %Y";
		            //this.gantt.templates.date_scale = null;
		            this.gantt.config.scale_height = 25;
		            this.gantt.config.row_height = 25;
		            this.gantt.config.subscales = [
		                { unit: "week", step: 1, date: "%W" }
		            ];
					break;
					
				case 'day':
					this.gantt.config.scale_height = 25;
					this.gantt.config.row_height = 25;
					this.gantt.config.scale_unit = "day";
					this.gantt.config.subscales = [
						{unit: "month", step: 1, date: "%M %Y"}
					];
					break;
			}
		},
		getMAD: function (murl) {
    		if (murl === null) {
    			murl = site + "/_api/lists/getbytitle('MilestonesAndDeliverables')/items?";
	        	murl += "$select=*,MileStoneLead/Title,MileStoneLead/ID,MileStoneLead/Name";
	        	murl += "&$orderby=MilestoneOrder&$expand=MileStoneLead";
	            murl += "&$filter=(ERPID eq '" + this.erpid + "')";
	        }
    	
    		var vm = this;
            jQuery.ajax({
                url: murl,
                method: "GET",
                headers: { 'accept': 'application/json; odata=verbose' },
                error: function (jqXHR, textStatus, errorThrown) {
                    logit("Error Status: " + textStatus + ":: errorThrown: " + errorThrown);
                },
                success: function (data) {
                	vm.mstd = vm.mstd.concat(data.d.results);
                	if (data.d.__next) {
                		murl = data.d.__next;
                		vm.getMAD(murl);
                	}
                	else {
                		var j = jQuery.parseJSON(JSON.stringify(vm.mstd));
                		vm.buildGantt(j);
                	}
                }
            });
    	},
    	buildGantt: function (j) {
			if (j.length > 0) {
    			this.totalrows = j.length;
        		for (var i = 0; i < j.length; i++) {
        			if (moment(j[i]["PlannedStart"]).isValid() && moment(j[i]["PlannedFinish"]).isValid()) { // needs to be a valid planned start and planned finish date
	        			// add planned milestone data as a project type
	        			// {id: 1, text: 'Task #1', start_date: '15-01-2019', duration: 15, progress: 0.6},
	        			var a = moment(j[i]["PlannedStart"]);
	    				var b = moment(j[i]["PlannedFinish"]);
	    				//logit("PLAN: " + b.diff(a, 'days') + ", " + a.diff(b, 'days'))
	    				var d = b.diff(a, 'days');
	        			this.tasks.data.push({
	        				"id": j[i]["ID"] + "_planned",
	        				"text": j[i]["CriticalPath"] === 'Y' ? j[i]["Title"] + " (CRITICAL)" : j[i]["Title"],
	        				"type": 0,
	        				"cls": j[i]["CriticalPath"] === 'Y' ? 'critical' : 'planned',
	        				"start_date": a.format("MM/DD/YYYY"),
	        				"duration": d,
	        				"progress": j[i]["PercentComplete"],
	        				"open": false
	        			});
	        			// add actual milestone data as a task for the project
	        			if (moment(j[i]["ActualStart"]).isValid()) { // must have a valid actual start date
	        				// is there an actual finish yet? is there a projected finish? 
	        				// current logic: first if actual finish then go to there
	        				// second if projected finish go to there
	        				// third use today if not actual or projected
	        				var f, g, h, k;
	        				f = moment(); // today
	        				g = 'notfinished';
	        				switch (true) {
	        					case moment(j[i]["ActualFinish"]).isValid():
	        						f = moment(j[i]["ActualFinish"]);
	        						g = 'actual';
	        						break;
	        						
	        					case moment(j[i]["ProjectedFinish"]).isValid():
	        						f = moment(j[i]["ProjectedFinish"]);
	        						g = 'projected';
	        						break;	        						
	        				}
	        				h = moment(j[i]["ActualStart"]);
	        				//a.add(a.utcOffset() * -1, 'm');
	        				k = f.diff(h, 'days');
	        				logit("Start: " + h.format("MM/DD/YYYY") + ", End: " + f.format("MM/DD/YYYY") + ", Duration: " + k);
	            			this.tasks.data.push({
	            				"id": j[i]["ID"] + "_actual",
	            				"text": 'Actual',
	            				"cls": g,
	            				"start_date": h.format("MM/DD/YYYY"),
	            				"duration": k,
	            				"progress": j[i]["PercentComplete"],
	            				"open": false
	            			});		                				
	        			}
	        		}
    			}
    			this.drawGantt();
    		}
		},
		drawGantt: function () {
			this.gantt.templates.task_class = function (start, end, task) {
	            switch (task.cls) {
	                case "planned":
	                    return "planned";
	                    break;
	
	                case "actual":
	                    return "actual";
	                    break;
	
	                case "projected":
	                    return "projected";
	                    break;
	
	                case "today":
	                    return "today";
	                    break;
					
					case "critical":
	                    return "critical";
	                    break;
	            }
	        };
	        
	        //this.gantt.config.smart_scales = false;
	        this.gantt.config.date_grid = "%m/%d/%Y";
	        
	        this.gantt.addMarker({
	        	start_date: new Date(),
	        	css: "todaymarker",
	        	text: "Today",
	        	title: "Today"
	        });
	        			
			this.gantt.templates.grid_row_class = function(start, end, task){
			    return "ganttrow_timeline";
			};
			
			this.gantt.config.xml_date = "%m/%d/%Y";
			this.gantt.config.min_column_width = 40;
			this.gantt.config.fit_tasks = true;
			this.gantt.init('ganttdiv_' + this.erpid);
			this.gantt.parse(this.tasks);
			this.setScale("month");
			this.loading = false;
		}
    }
}
