var IH = IH || {};
IH.ADMIN = IH.ADMIN || {};

IH.ADMIN.VARIABLES = {
    SLASH: "/",
    site: null,
    digest: null,
    response: [],
    data: null,
    json: null,
    total: 0,
    count: 0,
    batchsize: 0,
    milestones: [],
    oldmilestones: [],
    newmilestones: [],
    tempdata: []
}

var v = IH.ADMIN.VARIABLES;

IH.ADMIN.ACTIONS = function () {
	function loadCSS(url) {
	    var head = document.getElementsByTagName('head')[0];
	    var style = document.createElement('link');
	    style.type = 'text/css';
	    style.rel = 'stylesheet';
	    style.href = url;
	    head.appendChild(style);
	    //logit("CSS File Loaded: " + url);
	}

	function loadscript(url, callback) {
	    var script = document.createElement("script")
	    script.type = "text/javascript";
	    if (script.readyState) {  //IE
	        script.onreadystatechange = function () {
	            if (script.readyState == "loaded" ||
	                    script.readyState == "complete") {
	                script.onreadystatechange = null;
	                callback();
	            }
	        };
	    } else {  //Others
	        script.onload = function () {
	            callback();
	        };
	    }
	    script.src = url;
	    document.documentElement.insertBefore(script, document.documentElement.firstChild);
	}

	function UpdateLinkSucceeded() {
	    window.location = window.location; // refresh page
	}
	
	function UpdateLinkFailed(sender, args) {
	    alert("UpdateLinkFailed: " + args.get_message());
	}

	function Init(site) {
		v.site = site;
		
		console.log('Page Init Complete');
		loadCSS('https://cdn.jsdelivr.net/npm/bootstrap@4.2.1/dist/css/bootstrap.min.css');
		
		//loadscript('https://cdn.jsdelivr.net/npm/jquery@3.2.1/dist/jquery.min.js', function () {
			loadscript(site + '/SiteAssets/js/ihutilities.js', function () {
				$("#btnUpdate").click(function () {	
					var ctx = SP.ClientContext.get_current();
				    var web = ctx.get_web();
				    var lists = web.get_lists();
				    var list = lists.getByTitle($("#txtList").val());
				    var fields = list.get_fields();
				    var field = fields.getByInternalNameOrTitle($("#txtField").val())
				    field.set_jsLink($("#txtLink").val())
				    field.update()
				    ctx.executeQueryAsync(UpdateLinkSucceeded, UpdateLinkFailed)
				});
				$("#btnMigrate").click(function () {
					$("#btnMigrate").html("Getting Old MD Data...");
					IH.GLOBAL.ACTIONS.getFormDigest(site).then(function (data) {
        				IH.GLOBAL.VARIABLES.digest = data.d.GetContextWebInformation.FormDigestValue;
						getOldMAD(null);
					});
				});
			});
		//});	
	}
	
	function getOldMAD(murl) {
		if (murl === null) {
	        murl = v.site + "/_api/lists/getbytitle('VMDeliverableMilestones')/items?";
	    	murl += "$select=*,ERPDR/Title,WC/Title";
	    	murl += "&$orderby=ID&$expand=ERPDR,WC";
	    }
	    
	    jQuery.ajax({
            url: murl,
            method: "GET",
            headers: { 'accept': 'application/json; odata=verbose' },
            error: function (jqXHR, textStatus, errorThrown) {
                logit("Error Status: " + textStatus + ":: errorThrown: " + errorThrown);
            },
            success: function (data) {
                v.tempdata = v.tempdata.concat(data.d.results);
                if (data.d.__next) {
                	murl = data.d.__next;
                	getOldMAD(murl);
                }
                else {
                	v.oldmilestones = jQuery.parseJSON(JSON.stringify(v.tempdata));
                	v.tempdata = [];
                	var stop = 'stop';
                	//$("#btnMigrate").html("Getting New MD Data...");
                	//getNewMAD(null);
        			for (var j = 0; j < v.oldmilestones.length; j++) {
        				$("#txtData").append("\r\n" + "Item ID=" + v.oldmilestones[j]["ID"] + ", Title:" + v.oldmilestones[j]["Title"]);
        				v.newmilestones.push(v.oldmilestones[j]);
					}
					var stop = 'stop';
					IH.GLOBAL.VARIABLES.total = v.newmilestones.length;
					updateData(0);
                }
            }
        });

	}
	
	function getNewMAD(murl) {
		if (murl === null) {
	    	murl = v.site + "/_api/lists/getbytitle('MilestonesAndDeliverables')/items?";
	        murl += "$select=*";
	        murl += "&$orderby=ERPID";
	    }
	    
	    jQuery.ajax({
            url: murl,
            method: "GET",
            headers: { 'accept': 'application/json; odata=verbose' },
            error: function (jqXHR, textStatus, errorThrown) {
                logit("Error Status: " + textStatus + ":: errorThrown: " + errorThrown);
            },
            success: function (data) {
                v.tempdata = v.tempdata.concat(data.d.results);
                if (data.d.__next) {
                	murl = data.d.__next;
                	getNewMAD(murl);
                }
                else {
                	v.newmilestones = jQuery.parseJSON(JSON.stringify(v.tempdata));
                	var stop = 'stop';
                	$("#btnMigrate").html("Parsing Data...");
                	//parseData();
                	
                }
            }
        });
	}
	
	function parseData() {
		for (var j = 0; j < v.oldmilestones.length; j++) {
			// build array data with new attributes first
			v.oldmilestones[j].exists = false;
			for (var k = 0; k < v.newmilestones.length; k++) {
				if (v.oldmilestones[j]["ERPDR"]["Title"] === v.newmilestones[k]["ERPID"]) {
					if (v.oldmilestones[j]["Title"] === v.newmilestones[k]["Title"]) {
						// update any changed data
						v.newmilestones[k].OldID =  v.oldmilestones[j]["ID"];
						v.oldmilestones[j].exists = true;
						v.oldmilestones[j].updateID = v.newmilestones[k]["ID"];
						v.oldmilestones[j].index = k;
						v.oldmilestones[j].updated = false;
					}
				}
			}
		}
		var stop = 'stop';
		IH.GLOBAL.VARIABLES.total = v.oldmilestones.length;
        updateData(0);
	}
	
	function updateData(count) {
		// This function will be recursive and attempt to update 100 records at a time untill all records are updated
		$("#btnMigrate").html("Updating Data... Count: " + count);
		if (v.newmilestones.length > 100) {
			v.batchsize = 100;
		}
		else {
			v.batchsize = v.newmilestones.length;		
		}	
		IH.GLOBAL.VARIABLES.batchend = count + v.batchsize;
		for (var k = 0; k < v.batchsize; k++) {
				var item = v.newmilestones.shift();
				$("#txtData").append("\r\n" + "Item " + item["ID"] + " -- Action ");
				var itemprops = {
					"__metadata": { "type": "SP.Data.MilestonesAndDeliverablesListItem"},
					"ERPID": item["ERPDR"]["Title"],
					"Title": item["Title"],
                	"CriticalPath": item["CriticalPath"] === false ? 'N' : 'Y',
      				"PlannedFinish": moment(item["PlannedFinish"]).isValid() ? moment(item["PlannedFinish"]) : null,
      				"ProjectedFinish": moment(item["ProjectedDate"]).isValid() ? moment(item["ProjectedDate"]) : null,
      				"ActualFinish": moment(item["ActualFinish"]).isValid() ? moment(item["ActualFinish"]) : null,     							
      				"PercentComplete": Number(item["PercentComplete"]),
      				"PlannedQuantity": Number(item["PlannedDelivery"]),
      				"ActualQuantity": Number(item["ActualDelivery"]),
      				"OnTimeQuantity": Number(item["OnTimeDelivery"]),
      				"Units": item["Units"],
      				"LeadWC": item["WC"]["Title"],
					"Comments": item["Comments"],
					"OldID": item["ID"]
				};
				var itemdata = {};
				itemdata.itemprops = itemprops;
				itemdata.action = "updateData";
				IH.GLOBAL.ACTIONS.addNewItem(site, "MilestonesAndDeliverables", itemprops).success(IH.GLOBAL.ACTIONS.addNewItemSuccess.bind(itemdata)).fail(IH.GLOBAL.ACTIONS.addNewItemFail.bind(itemdata));
		}
	}

	/*
	function updateData(start) {
		// This function will be recursive and attempt to update 100 records at a time untill all records are updated
		IH.GLOBAL.VARIABLES.batchstart = start;
		$("#btnMigrate").html("Updating Data... Start: " + start);
		if (IH.GLOBAL.VARIABLES.count < IH.GLOBAL.VARIABLES.total - 100) {
			v.batchsize = 100;
		}
		else {
			v.batchsize = v.total = v.count;		
		}	
		IH.GLOBAL.VARIABLES.batchend = IH.GLOBAL.VARIABLES.batchstart + v.batchsize;
		for (var j = IH.GLOBAL.VARIABLES.batchstart; j < IH.GLOBAL.VARIABLES.batchend; j++) {
			$("#txtData").append("\r\n" + "Item " + j + " -- Action ");
			if (v.oldmilestones[j].exists === true) {
				// Existing item that needs to be updated. Some fields should not be updated since they don't really exist in the old list or their calculations have changed
				var itemprops = {
					"__metadata": { "type": "SP.Data.MilestonesAndDeliverablesListItem"},
                	"CriticalPath": v.oldmilestones[j]["CriticalPath"] === false ? 'N' : 'Y',
      				"PlannedFinish": moment(v.oldmilestones[j]["PlannedFinish"]).isValid() ? moment(v.oldmilestones[j]["PlannedFinish"]) : null,
      				"ProjectedFinish": moment(v.oldmilestones[j]["ProjectedDate"]).isValid() ? moment(v.oldmilestones[j]["ProjectedDate"]) : null,
      				"ActualFinish": moment(v.oldmilestones[j]["ActualFinish"]).isValid() ? moment(v.oldmilestones[j]["ActualFinish"]) : null,     							
      				"PercentComplete": Number(v.oldmilestones[j]["PercentComplete"]),
      				"PlannedQuantity": Number(v.oldmilestones[j]["PlannedDelivery"]),
      				"ActualQuantity": Number(v.oldmilestones[j]["ActualDelivery"]),
      				"OnTimeQuantity": Number(v.oldmilestones[j]["OnTimeDelivery"]),
      				"Units": v.oldmilestones[j]["Units"],
      				"LeadWC": v.oldmilestones[j]["WC"]["Title"],
					"Comments": v.oldmilestones[j]["Comments"]
				};
				var itemdata = {};
				itemdata.itemprops = itemprops;
				itemdata.ID = v.oldmilestones[j].updateID;
				itemdata.action = "updateData";
				itemdata.ue = "txtData";
				IH.GLOBAL.ACTIONS.getItemById(site, "MilestonesAndDeliverables", itemdata.ID).success(IH.GLOBAL.ACTIONS.getItemByIdSuccess.bind(itemdata));
			}
			else {
				// New item that needs to be added
				var itemprops = {
					"__metadata": { "type": "SP.Data.MilestonesAndDeliverablesListItem"},
					"ERPID": v.oldmilestones[j]["ERPDR"]["Title"],
					"Title": v.oldmilestones[j]["Title"],
                	"CriticalPath": v.oldmilestones[j]["CriticalPath"] === false ? 'N' : 'Y',
      				"PlannedFinish": moment(v.oldmilestones[j]["PlannedFinish"]).isValid() ? moment(v.oldmilestones[j]["PlannedFinish"]) : null,
      				"ProjectedFinish": moment(v.oldmilestones[j]["ProjectedDate"]).isValid() ? moment(v.oldmilestones[j]["ProjectedDate"]) : null,
      				"ActualFinish": moment(v.oldmilestones[j]["ActualFinish"]).isValid() ? moment(v.oldmilestones[j]["ActualFinish"]) : null,     							
      				"PercentComplete": Number(v.oldmilestones[j]["PercentComplete"]),
      				"PlannedQuantity": Number(v.oldmilestones[j]["PlannedDelivery"]),
      				"ActualQuantity": Number(v.oldmilestones[j]["ActualDelivery"]),
      				"OnTimeQuantity": Number(v.oldmilestones[j]["OnTimeDelivery"]),
      				"Units": v.oldmilestones[j]["Units"],
      				"LeadWC": v.oldmilestones[j]["WC"]["Title"],
					"Comments": v.oldmilestones[j]["Comments"]
				};
				var itemdata = {};
				itemdata.itemprops = itemprops;
				itemdata.action = "updateData";
				itemdata.ue = "txtData";
				IH.GLOBAL.ACTIONS.addNewItem(site, "MilestonesAndDeliverables", itemprops).success(IH.GLOBAL.ACTIONS.addNewItemSuccess.bind(itemdata)).fail(IH.GLOBAL.ACTIONS.addNewItemFail.bind(itemdata));
			}
		}
	}
	*/
	return {
        Init: Init,
        updateData: updateData 
    }
}